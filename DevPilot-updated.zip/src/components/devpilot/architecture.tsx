"use client";

import {
  Crown,
  Swords,
  ShieldCheck,
  BadgeCheck,
  Eye,
  User,
  ScrollText,
  ArrowDown,
  ShieldAlert,
} from "lucide-react";

const NODE =
  "flex items-center gap-2 rounded-lg border bg-card/80 px-3 py-2.5 text-left shadow-sm";

function Arrow() {
  return (
    <div className="flex justify-center py-1 text-zinc-600">
      <ArrowDown className="h-4 w-4" />
    </div>
  );
}

export function Architecture() {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      {/* Diagram */}
      <div className="rounded-xl border border-border bg-card/40 p-4">
        <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-amber-300/90">
          Guild Architecture
        </h3>
        <div className="mx-auto max-w-md space-y-0">
          <div className="flex items-center justify-center gap-2 text-center text-xs text-zinc-400">
            <User className="h-3.5 w-3.5 text-orange-300" />
            Natural-language request + local repo
          </div>
          <Arrow />
          <div className={`${NODE} border-amber-400/30`}>
            <Crown className="h-4 w-4 shrink-0 text-amber-300" />
            <div>
              <p className="text-xs font-semibold text-amber-200">Shogun — Planner / Orchestrator</p>
              <p className="text-[10px] text-zinc-400">objectives · task graph · delegation · re-planning</p>
            </div>
          </div>
          <Arrow />
          <div className="grid gap-2 sm:grid-cols-2">
            <div className={`${NODE} border-rose-500/30`}>
              <Swords className="h-4 w-4 shrink-0 text-rose-400" />
              <div>
                <p className="text-xs font-semibold text-rose-200">Samurai — Developer</p>
                <p className="text-[10px] text-zinc-400">read · search · edit · terminal</p>
              </div>
            </div>
            <div className={`${NODE} border-emerald-500/30`}>
              <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-400" />
              <div>
                <p className="text-xs font-semibold text-emerald-200">Sentinel — Tester</p>
                <p className="text-[10px] text-zinc-400">run tests · parse failures · findings</p>
              </div>
            </div>
            <div className={`${NODE} border-lime-400/30`}>
              <BadgeCheck className="h-4 w-4 shrink-0 text-lime-300" />
              <div>
                <p className="text-xs font-semibold text-lime-200">Apostle — Verifier</p>
                <p className="text-[10px] text-zinc-400">independent acceptance checks</p>
              </div>
            </div>
            <div className={`${NODE} border-violet-500/30`}>
              <Eye className="h-4 w-4 shrink-0 text-violet-400" />
              <div>
                <p className="text-xs font-semibold text-violet-200">Shadow Council — Review</p>
                <p className="text-[10px] text-zinc-400">code review · security inspection</p>
              </div>
            </div>
          </div>
          <Arrow />
          <div className={`${NODE} justify-center border-zinc-400/30`}>
            <ScrollText className="h-4 w-4 shrink-0 text-zinc-300" />
            <div>
              <p className="text-xs font-semibold text-zinc-100">Shared Mission State (blackboard)</p>
              <p className="text-[10px] text-zinc-400">task status · findings · decisions · open issues — every agent reads & writes</p>
            </div>
          </div>
          <Arrow />
          <div className={`${NODE} justify-center border-orange-400/40`}>
            <ShieldAlert className="h-4 w-4 shrink-0 text-orange-300" />
            <div>
              <p className="text-xs font-semibold text-orange-200">Human Gate — Daimyō approval</p>
              <p className="text-[10px] text-zinc-400">no consequential action without you · bounded autonomy · escalation</p>
            </div>
          </div>
        </div>
        <p className="mt-4 text-center text-[11px] leading-relaxed text-zinc-500">
          Coordination is event-driven over the shared blackboard — agents react to each
          other&apos;s findings (test failures, review findings, ambiguity) and the plan is revised.
          This is not a fixed pipeline of persona prompts.
        </p>
      </div>

      {/* Facts */}
      <div className="space-y-4">
        <div className="rounded-xl border border-border bg-card/40 p-4">
          <h3 className="mb-2 text-sm font-semibold uppercase tracking-wider text-amber-300/90">
            Tools &amp; Execution Boundaries
          </h3>
          <ul className="space-y-1.5 text-xs leading-relaxed text-zinc-300">
            <li>• <b className="text-zinc-100">6 tools:</b> read_file · search_repo · edit_file · write_file · run_tests · security_scan</li>
            <li>• <b className="text-zinc-100">Sandboxed:</b> all operations restricted to the mission repository</li>
            <li>• <b className="text-zinc-100">Destructive ops blocked:</b> no rm -rf, no network calls, no writes outside the repo</li>
            <li>• <b className="text-zinc-100">Evidence-based completion:</b> success is only claimed when test runs &amp; verification say so</li>
            <li>• <b className="text-zinc-100">Bounded autonomy:</b> 1 revision retry after rejection → then escalation to human, never an endless loop</li>
          </ul>
        </div>
        <div className="rounded-xl border border-border bg-card/40 p-4">
          <h3 className="mb-2 text-sm font-semibold uppercase tracking-wider text-amber-300/90">
            Feedback Loops In This Demo
          </h3>
          <ul className="space-y-1.5 text-xs leading-relaxed text-zinc-300">
            <li>• <b className="text-rose-300">Red → green repair</b> (Recovery mission): Sentinel narrows the diagnosis between failed attempts and the Samurai revises strategy</li>
            <li>• <b className="text-rose-300">Bug reproduction</b> (Bug mission): failing regression test written first, evidence drives the fix</li>
            <li>• <b className="text-rose-300">Review rejection</b> (any mission): your rejection sends findings back to the Samurai with one bounded retry</li>
            <li>• <b className="text-rose-300">Ambiguity escalation</b> (Ambiguity mission): the Shogun stops instead of guessing and asks you to clarify</li>
          </ul>
        </div>
        <div className="rounded-xl border border-border bg-card/40 p-4">
          <h3 className="mb-2 text-sm font-semibold uppercase tracking-wider text-amber-300/90">
            Mission Scenarios (from the problem statement)
          </h3>
          <ul className="space-y-1.5 text-xs leading-relaxed text-zinc-300">
            <li>• <b className="text-zinc-100">Feature</b> — add input validation, preserve behaviour</li>
            <li>• <b className="text-zinc-100">Bug</b> — fix a seeded off-by-one defect using repo context</li>
            <li>• <b className="text-zinc-100">Recovery</b> — repair a repository with a failing test</li>
            <li>• <b className="text-zinc-100">Security</b> — detect &amp; remediate a planted credential</li>
            <li>• <b className="text-zinc-100">Ambiguity</b> — handle a vague requirement via human clarification</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
