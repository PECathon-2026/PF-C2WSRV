"use client";

import { useState } from "react";
import {
  Crown,
  Swords,
  ShieldCheck,
  BadgeCheck,
  Eye,
  User,
  ScrollText,
  Wrench,
  FlaskConical,
  MessageSquare,
  FileDiff,
  ListChecks,
  ShieldAlert,
  ChevronDown,
  ChevronRight,
  CircleCheck,
  CircleX,
} from "lucide-react";
import type { AgentId } from "@/lib/devpilot/types";

// ── Agent identity ───────────────────────────────────────────────────────────

export const AGENT_STYLE: Record<
  AgentId,
  { name: string; icon: React.ElementType; color: string; bg: string; border: string }
> = {
  shogun: { name: "Shogun", icon: Crown, color: "text-amber-300", bg: "bg-amber-400/10", border: "border-amber-400/30" },
  samurai: { name: "Samurai", icon: Swords, color: "text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/30" },
  sentinel: { name: "Sentinel", icon: ShieldCheck, color: "text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/30" },
  verifier: { name: "Apostle", icon: BadgeCheck, color: "text-lime-300", bg: "bg-lime-400/10", border: "border-lime-400/30" },
  shadow: { name: "Shadow Council", icon: Eye, color: "text-violet-400", bg: "bg-violet-500/10", border: "border-violet-500/30" },
  human: { name: "Daimyō", icon: User, color: "text-orange-300", bg: "bg-orange-400/10", border: "border-orange-400/30" },
  system: { name: "Mission State", icon: ScrollText, color: "text-zinc-300", bg: "bg-zinc-400/10", border: "border-zinc-400/25" },
};

export function AgentBadge({ agent, small }: { agent: AgentId; small?: boolean }) {
  const s = AGENT_STYLE[agent] || AGENT_STYLE.system;
  const Icon = s.icon;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 font-medium ${s.bg} ${s.border} ${s.color} ${small ? "text-[10px]" : "text-xs"}`}
    >
      <Icon className={small ? "h-3 w-3" : "h-3.5 w-3.5"} />
      {s.name}
    </span>
  );
}

const TYPE_META: Record<string, { icon: React.ElementType; label: string; color: string }> = {
  tool_call: { icon: Wrench, label: "tool", color: "text-sky-300" },
  file_edit: { icon: FileDiff, label: "edit", color: "text-rose-300" },
  test: { icon: FlaskConical, label: "test", color: "text-emerald-300" },
  message: { icon: MessageSquare, label: "message", color: "text-amber-300" },
  plan: { icon: ListChecks, label: "plan", color: "text-amber-200" },
  tasks: { icon: ListChecks, label: "board", color: "text-zinc-300" },
  state: { icon: ScrollText, label: "state", color: "text-zinc-300" },
  review: { icon: Eye, label: "review", color: "text-violet-300" },
  security: { icon: ShieldAlert, label: "security", color: "text-violet-300" },
  verify: { icon: BadgeCheck, label: "verify", color: "text-lime-300" },
  approval_request: { icon: User, label: "gate", color: "text-orange-300" },
  approval_decision: { icon: User, label: "decision", color: "text-orange-300" },
  apply: { icon: FileDiff, label: "apply", color: "text-rose-300" },
  complete: { icon: CircleCheck, label: "done", color: "text-emerald-300" },
};

// ── Detail renderers ─────────────────────────────────────────────────────────

function DiffView({ before, after }: { before: string; after: string }) {
  const isNew = before.includes("did not exist");
  return (
    <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
      {!isNew && (
        <div className="overflow-hidden rounded-md border border-rose-500/25">
          <div className="border-b border-rose-500/25 bg-rose-500/10 px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-rose-300">
            − before
          </div>
          <pre className="dp-scroll max-h-60 overflow-auto bg-black/40 p-2 text-[11px] leading-relaxed text-zinc-300">
            {before}
          </pre>
        </div>
      )}
      <div className="overflow-hidden rounded-md border border-emerald-500/25">
        <div className="border-b border-emerald-500/25 bg-emerald-500/10 px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-emerald-300">
          {isNew ? "+ new file" : "+ after"}
        </div>
        <pre className="dp-scroll max-h-60 overflow-auto bg-black/40 p-2 text-[11px] leading-relaxed text-zinc-300">
          {after}
        </pre>
      </div>
    </div>
  );
}

function BulletList({ items, marker }: { items: string[]; marker: string }) {
  return (
    <ul className="space-y-1 text-xs text-zinc-300">
      {items.map((it, i) => (
        <li key={i} className="flex gap-2">
          <span className="shrink-0 font-mono text-[10px] text-amber-400/80">{marker(i)}</span>
          <span>{it}</span>
        </li>
      ))}
    </ul>
  );
}

function SevChip({ severity }: { severity: string }) {
  const map: Record<string, string> = {
    critical: "bg-rose-500/15 text-rose-300 border-rose-500/40",
    warning: "bg-amber-500/15 text-amber-300 border-amber-500/40",
    info: "bg-zinc-500/15 text-zinc-300 border-zinc-500/40",
  };
  return (
    <span className={`rounded border px-1.5 py-0.5 text-[10px] font-semibold uppercase ${map[severity] || map.info}`}>
      {severity}
    </span>
  );
}

export function EventDetail({ type, detail }: { type: string; detail: any }) {
  if (!detail) return null;

  switch (type) {
    case "plan":
      return (
        <div className="space-y-3">
          <div>
            <p className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-amber-400/90">Objectives</p>
            <BulletList items={detail.objectives || []} marker={(i) => `${i + 1}.`} />
          </div>
          <div>
            <p className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-amber-400/90">Acceptance criteria</p>
            <BulletList items={detail.acceptanceCriteria || []} marker={(i) => `AC${i + 1}`} />
          </div>
          {detail.risks?.length > 0 && (
            <div>
              <p className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-amber-400/90">Risks</p>
              <BulletList items={detail.risks} marker={() => "⚠"} />
            </div>
          )}
        </div>
      );

    case "tasks": {
      const tasks: any[] = detail.tasks || [];
      const statusStyle: Record<string, string> = {
        done: "text-emerald-300 border-emerald-500/40 bg-emerald-500/10",
        in_progress: "text-amber-300 border-amber-500/40 bg-amber-500/10",
        pending: "text-zinc-400 border-zinc-500/40 bg-zinc-500/10",
        reopened: "text-rose-300 border-rose-500/40 bg-rose-500/10",
        blocked: "text-rose-300 border-rose-500/40 bg-rose-500/10",
      };
      return (
        <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
          {tasks.map((t) => (
            <div key={t.id} className="flex items-center gap-2 rounded border border-border/60 bg-black/20 px-2 py-1.5">
              <span className="font-mono text-[10px] text-zinc-500">{t.id}</span>
              <span className="flex-1 text-xs text-zinc-200">{t.title}</span>
              <span className={`rounded border px-1.5 py-0.5 text-[9px] font-semibold uppercase ${statusStyle[t.status] || statusStyle.pending}`}>
                {t.status.replace("_", " ")}
              </span>
            </div>
          ))}
        </div>
      );
    }

    case "state":
      return (
        <div className="grid grid-cols-1 gap-x-4 gap-y-1 rounded bg-black/20 p-2 sm:grid-cols-2">
          {(detail.snapshot || []).map((kv: any, i: number) => (
            <div key={i} className="flex gap-2 text-xs">
              <span className="shrink-0 font-mono text-[10px] uppercase tracking-wide text-zinc-500">{kv.key}</span>
              <span className="text-zinc-200">{kv.value}</span>
            </div>
          ))}
        </div>
      );

    case "tool_call":
      return (
        <div className="space-y-1 rounded-md border border-sky-500/20 bg-black/30 p-2">
          <p className="font-mono text-[11px] text-sky-300">
            {detail.tool}({detail.args})
          </p>
          <p className="dp-scroll max-h-24 overflow-auto font-mono text-[11px] text-zinc-400">{detail.result}</p>
        </div>
      );

    case "file_edit":
      return (
        <div className="space-y-1">
          <p className="font-mono text-[11px] text-rose-300">{detail.path}</p>
          <DiffView before={detail.before} after={detail.after} />
        </div>
      );

    case "message":
      return (
        <div className="rounded-md border border-amber-500/20 bg-amber-500/5 p-2">
          <p className="mb-1 text-[11px] text-zinc-400">
            <AgentBadge agent={detail.from} small /> <span className="mx-1 text-zinc-600">→</span>{" "}
            <AgentBadge agent={detail.to} small />
          </p>
          <p className="text-xs leading-relaxed text-zinc-200">{detail.body}</p>
          {detail.refs && <p className="mt-1 font-mono text-[10px] text-zinc-500">refs: {detail.refs}</p>}
        </div>
      );

    case "test": {
      const fail = detail.verdict === "fail";
      return (
        <div className={`space-y-1 rounded-md border p-2 ${fail ? "border-rose-500/30 bg-rose-500/5" : "border-emerald-500/30 bg-emerald-500/5"}`}>
          <div className="flex flex-wrap items-center gap-2">
            <span className={`rounded border px-1.5 py-0.5 text-[10px] font-bold ${fail ? "border-rose-500/50 text-rose-300" : "border-emerald-500/50 text-emerald-300"}`}>
              {fail ? "RED" : "GREEN"}
            </span>
            <span className="font-mono text-[11px] text-zinc-400">{detail.command}</span>
            <span className="text-[11px] text-zinc-400">
              {detail.passed}/{detail.total} passed
              {detail.failed > 0 && <span className="text-rose-300"> · {detail.failed} failed</span>}
            </span>
          </div>
          <pre className="dp-scroll max-h-44 overflow-auto font-mono text-[11px] leading-relaxed text-zinc-300">
            {(detail.output || []).join("\n")}
          </pre>
        </div>
      );
    }

    case "review":
    case "security": {
      const findings: any[] = detail.findings || [];
      return (
        <div className="space-y-2">
          {findings.length === 0 ? (
            <p className="flex items-center gap-1.5 text-xs text-emerald-300">
              <CircleCheck className="h-3.5 w-3.5" /> No issues found — verdict: {detail.verdict}
            </p>
          ) : (
            findings.map((f, i) => (
              <div key={i} className="space-y-1 rounded-md border border-violet-500/25 bg-black/25 p-2">
                {f.severity && <SevChip severity={f.severity} />}
                <p className="text-xs leading-relaxed text-zinc-200">{f.note || f.issue}</p>
                {f.remediation && <p className="text-[11px] text-zinc-400">Remediation: {f.remediation}</p>}
                {f.file && <p className="font-mono text-[10px] text-violet-300">{f.file}</p>}
              </div>
            ))
          )}
          {detail.verdict && findings.length > 0 && (
            <p className="text-[11px] font-semibold uppercase tracking-wider text-violet-300">verdict: {detail.verdict}</p>
          )}
        </div>
      );
    }

    case "verify":
      return (
        <div className="space-y-1">
          {(detail.criteria || []).map((c: any, i: number) => (
            <div key={i} className="flex items-start gap-2 rounded border border-lime-500/20 bg-black/20 px-2 py-1.5">
              {c.result === "pass" ? (
                <CircleCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
              ) : (
                <CircleX className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-400" />
              )}
              <div>
                <p className="text-xs font-medium text-zinc-100">{c.criterion}</p>
                <p className="text-[11px] text-zinc-400">evidence: {c.evidence}</p>
              </div>
            </div>
          ))}
        </div>
      );

    case "approval_request": {
      const checks: any[] = detail.checks || [];
      return (
        <div className="space-y-2 rounded-md border border-orange-500/30 bg-orange-500/5 p-2">
          <p className="text-xs leading-relaxed text-zinc-100">{detail.summary}</p>
          {detail.changedFiles?.length > 0 && (
            <p className="font-mono text-[11px] text-zinc-400">files: {detail.changedFiles.join(" · ")}</p>
          )}
          <div className="flex flex-wrap gap-1.5">
            {checks.map((c, i) => (
              <span
                key={i}
                className={`rounded border px-1.5 py-0.5 text-[10px] ${c.ok ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-rose-500/40 bg-rose-500/10 text-rose-300"}`}
              >
                {c.ok ? "✓" : "✗"} {c.label}
              </span>
            ))}
          </div>
          {detail.question && <p className="text-xs font-medium text-orange-200">{detail.question}</p>}
          {detail.options?.length > 0 && (
            <ul className="space-y-1">
              {detail.options.map((o: string, i: number) => (
                <li key={i} className="rounded border border-orange-500/25 bg-black/20 px-2 py-1 text-xs text-zinc-200">
                  <span className="mr-1.5 font-mono text-[10px] text-orange-300/80">{String.fromCharCode(65 + i)})</span>
                  {o}
                </li>
              ))}
            </ul>
          )}
        </div>
      );
    }

    case "approval_decision":
      return (
        <p className="rounded-md border border-orange-500/25 bg-black/25 p-2 text-xs text-zinc-200">
          decision: <span className="font-semibold text-orange-200">{detail.decision}</span>
          {detail.note ? ` — ${detail.note}` : ""}
        </p>
      );

    case "apply":
      return (
        <p className="font-mono text-[11px] text-zinc-300">
          applied → {(detail.changedFiles || []).join(" · ")}
        </p>
      );

    case "complete":
      return (
        <p className="rounded-md border border-emerald-500/30 bg-emerald-500/5 p-2 text-xs leading-relaxed text-emerald-100">
          {detail.outcome}
        </p>
      );

    default:
      return null;
  }
}

// ── The card ─────────────────────────────────────────────────────────────────

export function EventCard({ ev, defaultOpen }: { ev: any; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(!!defaultOpen);
  const meta = TYPE_META[ev.type];
  const Icon = meta?.icon || ScrollText;
  const hasDetail = ev.type !== "message"; // message body shows inline

  return (
    <div className="dp-anim-up group relative border-l-2 border-border/70 pl-4 transition-colors hover:border-primary/40">
      <div className={`absolute -left-[9px] top-3 rounded-full border bg-[oklch(0.21_0.016_305)] p-1 ${AGENT_STYLE[ev.agent as AgentId]?.border || "border-zinc-500/40"}`}>
        <Icon className={`h-3 w-3 ${meta?.color || "text-zinc-400"}`} />
      </div>
      <button
        onClick={() => hasDetail && setOpen(!open)}
        className="flex w-full items-start gap-2 py-2 text-left"
        aria-expanded={open}
      >
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <AgentBadge agent={ev.agent} small />
            {meta && <span className={`text-[9px] font-bold uppercase tracking-widest ${meta.color}`}>{meta.label}</span>}
            <span className="font-mono text-[9px] text-zinc-600">#{ev.seq + 1}</span>
          </div>
          <p className="mt-1 text-sm font-medium leading-snug text-zinc-100">{ev.title}</p>
          {ev.type === "message" && <div className="mt-1"><EventDetail type="message" detail={ev.detail} /></div>}
        </div>
        {hasDetail && (
          <span className="mt-1 text-zinc-600">
            {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </span>
        )}
      </button>
      {hasDetail && open && (
        <div className="pb-3">
          <EventDetail type={ev.type} detail={ev.detail} />
        </div>
      )}
    </div>
  );
}
