"use client";

import { useState } from "react";
import {
  Crown,
  Swords,
  ShieldCheck,
  BadgeCheck,
  Eye,
  User,
  Sparkles,
  Bug,
  HeartPulse,
  ShieldAlert,
  HelpCircle,
  Wand2,
  Rocket,
  Loader2,
  FolderOpen,
  FileCode2,
  CircleCheck,
  CircleX,
  ScrollText,
  History as HistoryIcon,
  Copy,
  Check,
} from "lucide-react";
import type { AgentId, MissionScenario } from "@/lib/devpilot/types";
import { AGENT_STYLE } from "./event-card";

export const SCENARIOS: {
  id: MissionScenario;
  label: string;
  jp: string;
  desc: string;
  icon: React.ElementType;
}[] = [
  { id: "custom", label: "Custom Mission", jp: "頼", desc: "Bring YOUR problem — the guild writes the code live", icon: Wand2 },
  { id: "recovery", label: "Test-Driven Recovery", jp: "修復", desc: "Suite is RED on main — repair it (feedback-loop demo)", icon: HeartPulse },
  { id: "bug", label: "Bug Investigation", jp: "探索", desc: "Seeded off-by-one defect — reproduce, fix, verify", icon: Bug },
  { id: "feature", label: "Feature Implementation", jp: "作成", desc: "Add validation without breaking behaviour", icon: Sparkles },
  { id: "security", label: "Security & Review", jp: "警備", desc: "Planted hardcoded credential before open-sourcing", icon: ShieldAlert },
  { id: "ambiguity", label: "Ambiguous Request", jp: "問", desc: "Vague requirement — the guild asks YOU", icon: HelpCircle },
];

// ── Scenario picker ──────────────────────────────────────────────────────────

export function ScenarioPicker({
  value,
  onChange,
  disabled,
}: {
  value: MissionScenario;
  onChange: (s: MissionScenario) => void;
  disabled: boolean;
}) {
  return (
    <div className="grid gap-2">
      {SCENARIOS.map((s) => {
        const Icon = s.icon;
        const active = s.id === value;
        return (
          <button
            key={s.id}
            disabled={disabled}
            onClick={() => onChange(s.id)}
            className={`flex items-center gap-3 rounded-lg border p-3 text-left transition-all duration-200 hover:-translate-y-0.5 active:scale-[0.98] disabled:opacity-50 disabled:hover:translate-y-0 ${
              active
                ? "border-primary/60 bg-primary/10 shadow-[0_0_18px_oklch(0.58_0.19_27/0.15)]"
                : "border-border bg-card/50 hover:border-primary/30 hover:bg-card hover:shadow-[0_4px_16px_oklch(0_0_0/0.3)]"
            }`}
          >
            <span className={`rounded-md border p-2 ${active ? "border-primary/50 bg-primary/15 text-primary-foreground" : "border-border bg-black/20 text-zinc-300"}`}>
              <Icon className="h-4 w-4" />
            </span>
            <span className="min-w-0">
              <span className="flex items-center gap-2">
                <span className="text-sm font-semibold text-zinc-100">{s.label}</span>
                <span className="text-[10px] text-amber-300/70">{s.jp}</span>
              </span>
              <span className="block text-[11px] leading-snug text-zinc-400">{s.desc}</span>
            </span>
          </button>
        );
      })}
    </div>
  );
}

// ── Agent status row ─────────────────────────────────────────────────────────

const AGENTS: AgentId[] = ["shogun", "samurai", "sentinel", "verifier", "shadow"];

export function AgentRow({ activeAgent, awaiting }: { activeAgent: AgentId | null; awaiting: boolean }) {
  return (
    <div className="grid grid-cols-3 gap-2 sm:grid-cols-3 md:grid-cols-6">
      {AGENTS.map((a) => {
        const s = AGENT_STYLE[a];
        const Icon = s.icon;
        const active = a === activeAgent;
        return (
          <div
            key={a}
            className={`dp-anim-up rounded-lg border bg-card/60 p-2.5 text-center transition-transform duration-200 hover:scale-105 ${s.border} ${active ? `dp-active bg-card ${s.bg}` : "opacity-80"}`}
            style={{ animationDelay: `${AGENTS.indexOf(a) * 70}ms` }}
          >
            <Icon className={`mx-auto h-5 w-5 ${s.color}`} />
            <p className="mt-1 truncate text-[11px] font-semibold text-zinc-100">{s.name}</p>
            <p className="text-[9px] leading-tight text-zinc-500">{active ? "working…" : "standby"}</p>
          </div>
        );
      })}
      <div
        className={`rounded-lg border p-2.5 text-center ${
          awaiting ? "dp-active border-orange-400/50 bg-orange-400/10" : "border-border bg-card/60 opacity-60"
        }`}
      >
        <User className={`mx-auto h-5 w-5 ${awaiting ? "text-orange-300" : "text-zinc-500"}`} />
        <p className="mt-1 truncate text-[11px] font-semibold text-zinc-100">Daimyō</p>
        <p className="text-[9px] leading-tight text-zinc-500">{awaiting ? "decision needed!" : "you"}</p>
      </div>
    </div>
  );
}

// ── Approval gate ────────────────────────────────────────────────────────────

export function ApprovalGate({
  detail,
  busy,
  onDecision,
}: {
  detail: any;
  busy: boolean;
  onDecision: (d: "approve" | "reject", payload: { choice?: string; reason?: string }) => void;
}) {
  const [choice, setChoice] = useState<string>(detail?.options?.[0] || "");
  const [reason, setReason] = useState("");
  const options: string[] = detail?.options || [];
  const isClarification = options.length > 0;

  return (
    <div className="dp-anim-gate rounded-xl border border-orange-400/50 bg-gradient-to-b from-orange-500/10 to-transparent p-4 shadow-[0_0_30px_oklch(0.7_0.15_60/0.12)]">
      <div className="mb-2 flex items-center gap-2">
        <User className="h-4 w-4 text-orange-300" />
        <h3 className="text-sm font-bold uppercase tracking-wider text-orange-200">
          Human Gate — your decision is required
        </h3>
      </div>
      <p className="text-xs leading-relaxed text-zinc-200">{detail?.summary}</p>
      {detail?.question && (
        <p className="mt-2 text-xs font-medium leading-relaxed text-orange-200">{detail.question}</p>
      )}
      {detail?.changedFiles?.length > 0 && (
        <p className="mt-2 font-mono text-[11px] text-zinc-400">files: {detail.changedFiles.join(" · ")}</p>
      )}
      {detail?.checks?.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {detail.checks.map((c: any, i: number) => (
            <span
              key={i}
              className={`rounded border px-1.5 py-0.5 text-[10px] ${c.ok ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-rose-500/40 bg-rose-500/10 text-rose-300"}`}
            >
              {c.ok ? "✓" : "✗"} {c.label}
            </span>
          ))}
        </div>
      )}

      {isClarification && (
        <div className="mt-3 space-y-1.5">
          {options.map((o, i) => (
            <label
              key={i}
              className={`flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-2 text-xs transition-colors ${
                choice === o ? "border-orange-400/60 bg-orange-400/10 text-orange-100" : "border-border bg-black/20 text-zinc-300 hover:border-orange-400/30"
              }`}
            >
              <input
                type="radio"
                name="dp-choice"
                className="accent-orange-400"
                checked={choice === o}
                onChange={() => setChoice(o)}
              />
              {o}
            </label>
          ))}
          <input
            value={choice && !options.includes(choice) ? choice : ""}
            onChange={(e) => setChoice(e.target.value)}
            placeholder="…or type your own requirement"
            className="w-full rounded-lg border border-border bg-black/30 px-3 py-2 text-xs text-zinc-100 placeholder:text-zinc-600 focus:border-orange-400/50 focus:outline-none"
          />
        </div>
      )}

      {!isClarification && (
        <input
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Optional reason if you reject…"
          className="mt-3 w-full rounded-lg border border-border bg-black/30 px-3 py-2 text-xs text-zinc-100 placeholder:text-zinc-600 focus:border-orange-400/50 focus:outline-none"
        />
      )}

      <div className="mt-3 flex flex-wrap gap-2">
        <button
          disabled={busy || (isClarification && !choice.trim())}
          onClick={() => onDecision("approve", { choice: choice || undefined })}
          className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-bold text-white transition-colors hover:bg-emerald-500 disabled:opacity-40"
        >
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CircleCheck className="h-3.5 w-3.5" />}
          {isClarification ? "Answer & proceed" : "Approve & apply"}
        </button>
        <button
          disabled={busy}
          onClick={() => onDecision("reject", { reason: reason || (isClarification ? "Declined to clarify" : "") })}
          className="inline-flex items-center gap-1.5 rounded-lg border border-rose-500/50 bg-rose-500/10 px-4 py-2 text-xs font-bold text-rose-300 transition-colors hover:bg-rose-500/20 disabled:opacity-40"
        >
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CircleX className="h-3.5 w-3.5" />}
          {isClarification ? "Decline" : "Reject"}
        </button>
      </div>
      <p className="mt-2 text-[10px] text-zinc-500">
        Bounded autonomy: after 2 rejections the mission escalates and stops — no endless loops.
      </p>
    </div>
  );
}

// ── Task board ───────────────────────────────────────────────────────────────

export function TaskBoard({ tasks }: { tasks: any[] }) {
  if (!tasks.length) {
    return <p className="text-xs text-zinc-500">No tasks yet — the Shogun plans after the mission starts.</p>;
  }
  const dot: Record<string, string> = {
    done: "bg-emerald-400",
    in_progress: "bg-amber-400 animate-pulse",
    reopened: "bg-rose-400 animate-pulse",
    blocked: "bg-rose-400",
    pending: "bg-zinc-600",
  };
  return (
    <div className="space-y-1.5">
      {tasks.map((t, i) => (
        <div
          key={t.id}
          className="dp-anim-slide flex items-center gap-2 rounded border border-border/60 bg-black/20 px-2.5 py-1.5 transition-colors hover:border-primary/30"
          style={{ animationDelay: `${i * 60}ms` }}
        >
          <span className={`h-2 w-2 shrink-0 rounded-full ${dot[t.status] || dot.pending}`} />
          <span className="font-mono text-[10px] text-zinc-500">{t.id}</span>
          <span className="min-w-0 flex-1 truncate text-xs text-zinc-200">{t.title}</span>
          <span className="shrink-0 text-[10px] text-zinc-500">{t.status.replace("_", " ")}</span>
        </div>
      ))}
    </div>
  );
}

// ── Shared mission state ─────────────────────────────────────────────────────

export function SharedState({ snapshot }: { snapshot: any[] }) {
  if (!snapshot?.length) return <p className="text-xs text-zinc-500">Blackboard is empty.</p>;
  return (
    <div className="space-y-1">
      {snapshot.map((kv, i) => (
        <div key={i} className="flex gap-2 text-xs">
          <span className="w-20 shrink-0 font-mono text-[10px] uppercase tracking-wide text-amber-300/70">{kv.key}</span>
          <span className="min-w-0 flex-1 break-words text-zinc-200">{kv.value}</span>
        </div>
      ))}
    </div>
  );
}

// ── Repo viewer ──────────────────────────────────────────────────────────────

export function RepoViewer({ repo }: { repo: any }) {
  const [sel, setSel] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  if (!repo) return null;
  const file = repo.files.find((f: any) => f.path === sel) || repo.files[0];

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(file?.content || "");
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {}
  };

  return (
    <div className="rounded-xl border border-border bg-card/40">
      <div className="flex items-center gap-2 border-b border-border/60 px-3 py-2">
        <FolderOpen className="h-3.5 w-3.5 text-amber-300/80" />
        <p className="text-xs font-semibold text-zinc-100">{repo.name}</p>
        <span className="text-[10px] text-zinc-500">· {repo.language} · {repo.description}</span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-[160px_minmax(0,1fr)]">
        <div className="dp-scroll max-h-52 overflow-auto border-b border-border/40 p-1.5 sm:border-b-0 sm:border-r">
          {repo.files.map((f: any) => (
            <button
              key={f.path}
              onClick={() => setSel(f.path)}
              className={`flex w-full items-center gap-1.5 rounded px-2 py-1.5 text-left text-[11px] ${
                f.path === file.path ? "bg-primary/15 text-zinc-100" : "text-zinc-400 hover:bg-black/20"
              }`}
            >
              <FileCode2 className="h-3 w-3 shrink-0 text-zinc-500" />
              <span className="truncate font-mono">{f.path}</span>
            </button>
          ))}
        </div>
        <div className="relative">
          <button
            onClick={copyCode}
            className="absolute right-2 top-2 z-10 inline-flex items-center gap-1 rounded-md border border-emerald-500/40 bg-emerald-500/15 px-2 py-1 text-[10px] font-bold text-emerald-300 backdrop-blur transition-colors hover:bg-emerald-500/25"
            aria-label="Copy file content"
          >
            {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
            {copied ? "COPIED!" : "COPY CODE"}
          </button>
          <pre className="dp-scroll max-h-52 overflow-auto bg-black/30 p-2 pt-9 text-[10px] leading-relaxed text-zinc-300">
            {file?.content}
          </pre>
        </div>
      </div>
    </div>
  );
}

// ── Mission history ──────────────────────────────────────────────────────────

export function History({
  missions,
  currentId,
  onSelect,
}: {
  missions: any[];
  currentId: string | null;
  onSelect: (id: string) => void;
}) {
  if (!missions.length) return <p className="text-xs text-zinc-500">No missions yet. Launch one!</p>;
  const statusColor: Record<string, string> = {
    completed: "text-emerald-300",
    running: "text-amber-300",
    preparing: "text-violet-300",
    awaiting_approval: "text-orange-300",
    escalated: "text-rose-300",
  };
  return (
    <div className="dp-scroll max-h-44 space-y-1 overflow-auto pr-1">
      {missions.map((m) => (
        <button
          key={m.id}
          onClick={() => onSelect(m.id)}
          className={`flex w-full items-center gap-2 rounded border px-2 py-1.5 text-left text-[11px] transition-colors ${
            m.id === currentId ? "border-primary/50 bg-primary/10" : "border-border/60 bg-black/20 hover:border-primary/30"
          }`}
        >
          <HistoryIcon className="h-3 w-3 shrink-0 text-zinc-500" />
          <span className="min-w-0 flex-1 truncate text-zinc-300">{m.request}</span>
          <span className={`shrink-0 font-semibold ${statusColor[m.status] || "text-zinc-400"}`}>
            {m.status.replace("_", " ")}
          </span>
        </button>
      ))}
    </div>
  );
}
