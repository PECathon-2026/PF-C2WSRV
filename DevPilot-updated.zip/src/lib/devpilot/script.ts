import type { AgentId, ScriptEvent } from "./types";

// ── Mission script builder ───────────────────────────────────────────────────
// Produces the guild's event script for each evaluation scenario.
// Events up to the first `approval_request` are pre-generated at mission start;
// rejection / clarification tails are appended dynamically by the API routes
// (adaptive orchestration — the plan changes when new evidence arrives).

type E = ScriptEvent;

const state = (title: string, snapshot: { key: string; value: string }[]): E => ({
  agent: "system",
  type: "state",
  title,
  detail: { snapshot },
});

const tasks = (title: string, list: Record<string, string>[]): E => ({
  agent: "system",
  type: "tasks",
  title,
  detail: { tasks: list },
});

const tool = (
  agent: AgentId,
  t: string,
  args: string,
  result: string,
  ok = true
): E => ({ agent, type: "tool_call", title: `${t} → ${args}`, detail: { tool: t, args, result, ok } });

const msg = (from: AgentId, to: AgentId, subject: string, body: string, refs?: string): E => ({
  agent: from,
  type: "message",
  title: `${subject}`,
  detail: { from, to, subject, body, refs },
});

const edit = (path: string, before: string, after: string): E => ({
  agent: "samurai",
  type: "file_edit",
  title: `edit_file → ${path}`,
  detail: { path, before, after },
});

const testEvent = (
  suite: string,
  command: string,
  passed: number,
  failed: number,
  output: string[],
  verdict: "pass" | "fail"
): E => ({
  agent: "sentinel",
  type: "test",
  title: `run_tests → ${suite} (${verdict === "pass" ? "GREEN" : "RED"})`,
  detail: { suite, command, total: passed + failed, passed, failed, verdict, output },
});

const approval = (detail: Record<string, unknown>): E => ({
  agent: "shogun",
  type: "approval_request",
  title: "Human approval requested",
  detail,
});

const verify = (criteria: { criterion: string; result: string; evidence: string }[], verdict: string): E => ({
  agent: "verifier",
  type: "verify",
  title: `Independent verification → ${verdict.toUpperCase()}`,
  detail: { criteria, verdict },
});

// ═════════════════════════════════════════════════════════════════════════════
// SCENARIO: feature — kanban-api, add input validation (clean run)
// ═════════════════════════════════════════════════════════════════════════════

const TASKS_FEATURE: Record<string, string>[] = [
  { id: "T1", title: "Analyse request → objectives & acceptance criteria", assignee: "shogun", status: "done" },
  { id: "T2", title: "Reconnaissance: locate POST /tasks handler & conventions", assignee: "shogun", status: "done" },
  { id: "T3", title: "Implement title validator (≤80 chars, clear 400 error)", assignee: "samurai", status: "pending" },
  { id: "T4", title: "Add regression tests for the new validation", assignee: "samurai", status: "pending" },
  { id: "T5", title: "Run full suite & verify acceptance criteria", assignee: "sentinel", status: "pending" },
  { id: "T6", title: "Review + security inspection of the change", assignee: "shadow", status: "pending" },
];

export function buildFeatureScript(): E[] {
  const routeBefore = `const express = require("express");
const router = express.Router();
const store = require("../store");

// POST /tasks — create a task
router.post("/tasks", (req, res) => {
  const { title, priority } = req.body;
  if (!title || typeof title !== "string") {
    return res.status(400).json({ error: "title is required" });
  }
  const task = store.add({ title: title.trim(), priority: priority || "normal" });
  res.status(201).json(task);
});`;
  const routeAfter = `const express = require("express");
const router = express.Router();
const store = require("../store");
const { validateTitle } = require("../validators/taskValidator");

// POST /tasks — create a task
router.post("/tasks", (req, res) => {
  const { title, priority } = req.body;
  const error = validateTitle(title);
  if (error) {
    return res.status(400).json({ error });
  }
  const task = store.add({ title: title.trim(), priority: priority || "normal" });
  res.status(201).json(task);
});`;
  const testsBefore = `const { test } = require("node:test");
const assert = require("node:assert");

test("creates a task with a title", () => {
  const store = require("../src/store");
  const task = store.add({ title: "Write README", priority: "normal" });
  assert.equal(task.title, "Write README");
});

test("list returns created tasks", () => {
  const store = require("../src/store");
  assert.ok(Array.isArray(store.list()));
});`;
  const testsAfter = testsBefore + `

test("rejects an empty title with 400", () => {
  const { validateTitle } = require("../src/validators/taskValidator");
  assert.ok(validateTitle("   "));
});

test("rejects a title longer than 80 chars", () => {
  const { validateTitle } = require("../src/validators/taskValidator");
  assert.ok(validateTitle("x".repeat(81)));
});`;
  const validatorFile = `const MAX_TITLE_LENGTH = 80;

/**
 * Returns an error message when the title is invalid, otherwise null.
 * Follows the project's existing style: tiny pure modules + CommonJS.
 */
function validateTitle(title) {
  if (!title || typeof title !== "string") {
    return "title is required";
  }
  const trimmed = title.trim();
  if (trimmed.length === 0) {
    return "title must not be empty";
  }
  if (trimmed.length > MAX_TITLE_LENGTH) {
    return \`title must be at most \${MAX_TITLE_LENGTH} characters\`;
  }
  return null;
}

module.exports = { validateTitle, MAX_TITLE_LENGTH };`;

  return [
    state("Mission opened", [
      { key: "mission", value: "Add input validation to POST /tasks" },
      { key: "repo", value: "kanban-api @ main (clean tree)" },
      { key: "phase", value: "planning" },
    ]),
    {
      agent: "shogun",
      type: "plan",
      title: "Requirement analysis — objectives & acceptance criteria",
      detail: {
        objectives: [
          "POST /tasks must reject titles that are empty or longer than 80 characters",
          "Rejections return HTTP 400 with a helpful, human-readable error message",
          "Existing behaviour (valid task creation, listing) must not change",
        ],
        acceptanceCriteria: [
          "AC1: empty/whitespace title → 400 with message about the title",
          "AC2: title of 81+ chars → 400 with message about the length limit",
          "AC3: valid title still creates a task and returns 201",
          "AC4: full test suite passes after the change",
        ],
        risks: ["Validation must not reject titles with internal spaces or emoji"],
      },
    },
    tool("shogun", "search_repo", "pattern=\"router.post\" ", "2 matches: src/routes/tasks.js:5 (POST /tasks), src/routes/users.js:8 (POST /users)"),
    tool("shogun", "read_file", "src/routes/tasks.js", "Read 24 lines. Handler currently checks only that title is a non-empty string — no length limit."),
    tool("shogun", "read_file", "tests/tasks.test.js", "Read 18 lines. Node test runner, plain asserts, one file per route module."),
    tasks("Task board updated — 6 tasks delegated", TASKS_FEATURE),
    msg(
      "shogun",
      "samurai",
      "Task T3+T4: implement title validation",
      "Implement per plan. Style note from recon: this repo uses tiny CommonJS modules with JSDoc comments — put the validator in its own module, do not inline it. T4: add tests for both new 400 cases.",
      "plan v1, AC1–AC4"
    ),
    tool("samurai", "read_file", "src/store.js", "Read 16 lines. Confirmed store.add trims nothing itself — trimming stays the route's job."),
    edit("src/validators/taskValidator.js (new file)", "// file did not exist", validatorFile),
    edit("src/routes/tasks.js", routeBefore, routeAfter),
    edit("tests/tasks.test.js", testsBefore, testsAfter),
    msg("samurai", "sentinel", "T3/T4 done — requesting test run", "Validator module, route wiring and 2 regression tests are in place. Please run the full suite."),
    tasks("Task board updated", TASKS_FEATURE.map((t) => (t.id === "T3" || t.id === "T4" ? { ...t, status: "done" } : t.id === "T5" ? { ...t, status: "in_progress" } : t))),
    testEvent("tests/", "npm test", 4, 0, [
      "▶ tests/tasks.test.js",
      "  ✔ creates a task with a title (2ms)",
      "  ✔ list returns created tasks (1ms)",
      "  ✔ rejects an empty title with 400 (1ms)",
      "  ✔ rejects a title longer than 80 chars (0ms)",
      "ℹ 4 tests passed, 0 failed (0.3s)",
    ], "pass"),
    msg("sentinel", "shogun", "Suite GREEN — 4/4", "Full suite passes. Evidence attached to run log. Requesting independent verification of AC1–AC4."),
    verify([
      { criterion: "AC1: empty title → 400", result: "pass", evidence: "test 'rejects an empty title with 400' green; validator returns 'title must not be empty'" },
      { criterion: "AC2: 81-char title → 400", result: "pass", evidence: "test 'rejects a title longer than 80 chars' green; MAX_TITLE_LENGTH = 80" },
      { criterion: "AC3: valid title still returns 201", result: "pass", evidence: "test 'creates a task with a title' green; happy path untouched" },
      { criterion: "AC4: full suite passes", result: "pass", evidence: "sentinel run #1: 4 passed, 0 failed" },
    ], "pass"),
    {
      agent: "shadow",
      type: "review",
      title: "Code review — approved with one note",
      detail: {
        findings: [
          { severity: "info", note: "Validator is a pure module with JSDoc — matches project conventions. Readable and testable." },
          { severity: "info", note: "Trailing spaces inside the 80-char limit are allowed (trimmed length is checked) — reasonable, documented behaviour." },
        ],
        verdict: "approve",
      },
    },
    {
      agent: "shadow",
      type: "security",
      title: "Security inspection — no issues found",
      detail: { findings: [] as { severity: string; note: string }[], verdict: "clean" },
    },
    tasks("Task board updated", TASKS_FEATURE.map((t) => ({ ...t, status: "done" }))),
    approval({
      summary:
        "Samurai implemented a dedicated taskValidator module (new file) wired into POST /tasks. 2 regression tests added. Suite 4/4 green, verification of AC1–AC4 passed, review approved, security scan clean.",
      changedFiles: ["src/validators/taskValidator.js (new)", "src/routes/tasks.js", "tests/tasks.test.js"],
      checks: [
        { label: "Tests 4/4 green", ok: true },
        { label: "Acceptance criteria verified", ok: true },
        { label: "Code review approved", ok: true },
        { label: "Security scan clean", ok: true },
      ],
      attempt: 1,
    }),
  ];
}

// ═════════════════════════════════════════════════════════════════════════════
// SCENARIO: bug — shopsearch, off-by-one on min query length (red → green loop)
// ═════════════════════════════════════════════════════════════════════════════

const TASKS_BUG: Record<string, string>[] = [
  { id: "T1", title: "Analyse defect report → acceptance criteria for the fix", assignee: "shogun", status: "done" },
  { id: "T2", title: "Reconnaissance: trace the search path", assignee: "shogun", status: "done" },
  { id: "T3", title: "Write failing regression test for 3-char queries", assignee: "samurai", status: "pending" },
  { id: "T4", title: "Investigate root cause & fix src/search.js", assignee: "samurai", status: "pending" },
  { id: "T5", title: "Run suite, verify fix, review the change", assignee: "sentinel", status: "pending" },
];

const SEARCH_BEFORE = `const CATALOG = require("./catalog");

const MIN_QUERY_LENGTH = 3;

/**
 * Search products by name. Case-insensitive substring match.
 */
function searchProducts(query, { limit = 20 } = {}) {
  if (typeof query !== "string") return [];

  const q = query.trim().toLowerCase();

  // Guard: ignore very short queries to protect performance
  if (q.length > MIN_QUERY_LENGTH) {
    const hits = CATALOG.filter((p) => p.name.toLowerCase().includes(q));
    return hits.slice(0, limit);
  }

  return [];
}

module.exports = { searchProducts, MIN_QUERY_LENGTH };`;

const SEARCH_AFTER = `const CATALOG = require("./catalog");

const MIN_QUERY_LENGTH = 3;

/**
 * Search products by name. Case-insensitive substring match.
 */
function searchProducts(query, { limit = 20 } = {}) {
  if (typeof query !== "string") return [];

  const q = query.trim().toLowerCase();

  // Guard: ignore very short queries to protect performance.
  // Queries of exactly MIN_QUERY_LENGTH chars are valid (e.g. "ps5").
  if (q.length >= MIN_QUERY_LENGTH) {
    const hits = CATALOG.filter((p) => p.name.toLowerCase().includes(q));
    return hits.slice(0, limit);
  }

  return [];
}

module.exports = { searchProducts, MIN_QUERY_LENGTH };`;

const TESTS_BEFORE_BUG = `const { test } = require("node:test");
const assert = require("node:assert");
const { searchProducts } = require("../src/search");

test("finds products by full name", () => {
  const hits = searchProducts("PlayStation");
  assert.equal(hits.length, 1);
  assert.equal(hits[0].id, 1);
});

test("returns empty for very short queries", () => {
  assert.deepEqual(searchProducts("a"), []);
});`;

const TESTS_AFTER_BUG = TESTS_BEFORE_BUG + `

test("regression: finds products by 3-char query (issue #41)", () => {
  const hits = searchProducts("ps5");
  assert.equal(hits.length, 2); // PS5 console + PS5 controller
});`;

export function buildBugScript(): E[] {
  return [
    state("Mission opened", [
      { key: "mission", value: "Investigate & fix: 3-char searches return no results" },
      { key: "repo", value: "shopsearch @ main (clean tree)" },
      { key: "phase", value: "planning" },
    ]),
    {
      agent: "shogun",
      type: "plan",
      title: "Bug report analysis — investigation plan",
      detail: {
        objectives: [
          "Root-cause why 3-character product queries return empty results",
          "Fix the defect without changing behaviour of any other query length",
        ],
        acceptanceCriteria: [
          "AC1: searchProducts('ps5') returns the 2 PS5 products",
          "AC2: 1-char queries still return [] (performance guard preserved)",
          "AC3: full suite passes including a new regression test",
        ],
        risks: ["Guard threshold may be intentional — check tests and comments before changing"],
      },
    },
    tool("shogun", "search_repo", "pattern=\"MIN_QUERY_LENGTH\"", "2 matches: src/search.js:3, src/search.js:13"),
    tool("shogun", "read_file", "src/search.js", "Read 24 lines. Guard uses q.length > MIN_QUERY_LENGTH — suspicious: excludes exactly-3-char queries."),
    tool("shogun", "read_file", "src/catalog.js", "Read 9 lines. Catalogue contains 'PS5'-prefixed products — report is reproducible in principle."),
    tasks("Task board updated — investigation delegated", TASKS_BUG),
    msg(
      "shogun",
      "samurai",
      "Task T3: reproduce first, then fix",
      "Reproduce the reported behaviour with a regression test BEFORE touching the implementation. Then investigate the guard in src/search.js:13. Hypothesis: off-by-one comparison, but confirm with evidence — the threshold may be intentional.",
      "plan v1, AC1–AC3"
    ),
    edit("tests/search.test.js", TESTS_BEFORE_BUG, TESTS_AFTER_BUG),
    testEvent("tests/", "npm test", 2, 1, [
      "▶ tests/search.test.js",
      "  ✔ finds products by full name (2ms)",
      "  ✔ returns empty for very short queries (0ms)",
      "  ✖ regression: finds products by 3-char query (issue #41) (3ms)",
      "    AssertionError: expected 2 hits, got 0 []",
      "      at searchProducts (src/search.js:17:12)",
      "ℹ 2 tests passed, 1 failed (0.3s)",
    ], "fail"),
    msg(
      "sentinel",
      "samurai",
      "RED confirmed — finding for your investigation",
      "Regression test fails exactly as reported: searchProducts('ps5') → 0 hits. The failure is in the guard at src/search.js:17, not in the catalogue filter — the function returns early before filtering. Root-cause hint: boundary condition of the length check.",
      "run #1 output"
    ),
    tasks("Task board updated", TASKS_BUG.map((t) => (t.id === "T3" ? { ...t, status: "done" } : t.id === "T4" ? { ...t, status: "in_progress" } : t))),
    tool("samurai", "read_file", "src/search.js:13", "q.length > MIN_QUERY_LENGTH — skips the filter for q.length === 3. Confirmed off-by-one: comment says 'ignore very short queries', so exactly-3 should pass. Fix: >= ."),
    edit("src/search.js", SEARCH_BEFORE, SEARCH_AFTER),
    testEvent("tests/", "npm test", 3, 0, [
      "▶ tests/search.test.js",
      "  ✔ finds products by full name (2ms)",
      "  ✔ returns empty for very short queries (0ms)",
      "  ✔ regression: finds products by 3-char query (issue #41) (1ms)",
      "ℹ 3 tests passed, 0 failed (0.3s)",
    ], "pass"),
    msg("sentinel", "shogun", "Suite GREEN — 3/3 after fix", "Run #2: the exact boundary ('ps5' → 2 hits) now passes and the 1-char guard still holds. Evidence in run log."),
    tasks("Task board updated", TASKS_BUG.map((t) => (t.id === "T3" || t.id === "T4" ? { ...t, status: "done" } : t.id === "T5" ? { ...t, status: "in_progress" } : t))),
    verify([
      { criterion: "AC1: searchProducts('ps5') → 2 PS5 products", result: "pass", evidence: "regression test green in run #2" },
      { criterion: "AC2: 1-char queries still return []", result: "pass", evidence: "test 'returns empty for very short queries' green in run #2" },
      { criterion: "AC3: full suite incl. regression test passes", result: "pass", evidence: "sentinel run #2: 3 passed, 0 failed" },
    ], "pass"),
    {
      agent: "shadow",
      type: "review",
      title: "Code review — approved",
      detail: {
        findings: [
          { severity: "info", note: "Minimal one-character change (>=). Comment updated to document the boundary — good." },
          { severity: "info", note: "Regression test named after issue #41 — traceable." },
        ],
        verdict: "approve",
      },
    },
    {
      agent: "shadow",
      type: "security",
      title: "Security inspection — no issues found",
      detail: { findings: [] as { severity: string; note: string }[], verdict: "clean" },
    },
    tasks("Task board updated", TASKS_BUG.map((t) => ({ ...t, status: "done" }))),
    approval({
      summary:
        "Root cause: off-by-one guard in src/search.js (q.length > 3 excluded exactly-3-char queries). Fixed to >= with a documented boundary, regression test added. Red→green loop: run #1 failed, run #2 green.",
      changedFiles: ["src/search.js", "tests/search.test.js"],
      checks: [
        { label: "Tests 3/3 green (was 2/3)", ok: true },
        { label: "Acceptance criteria verified", ok: true },
        { label: "Code review approved", ok: true },
        { label: "Security scan clean", ok: true },
      ],
      attempt: 1,
    }),
  ];
}

// ═════════════════════════════════════════════════════════════════════════════
// SCENARIO: recovery — pricing-service, failing suite on main (two-loop repair)
// ═════════════════════════════════════════════════════════════════════════════

const TASKS_RECOVERY: Record<string, string>[] = [
  { id: "T1", title: "Triage red suite → acceptance criteria", assignee: "shogun", status: "done" },
  { id: "T2", title: "Reconnaissance: which test fails & why", assignee: "shogun", status: "done" },
  { id: "T3", title: "Repair roundTo2 without weakening tests", assignee: "samurai", status: "pending" },
  { id: "T4", title: "Iterate with Sentinel until suite is green", assignee: "sentinel", status: "pending" },
  { id: "T5", title: "Independent verification + review", assignee: "verifier", status: "pending" },
];

const ROUNDING_BEFORE = `/**
 * Round a monetary amount to 2 decimal places (half-up).
 * Used by invoice and tax calculations.
 */
function roundTo2(value) {
  return Math.round(value * 100) / 100;
}

module.exports = { roundTo2 };`;

const ROUNDING_ATTEMPT1 = `/**
 * Round a monetary amount to 2 decimal places (half-up).
 * Used by invoice and tax calculations.
 */
function roundTo2(value) {
  return Number(value.toFixed(2));
}

module.exports = { roundTo2 };`;

const ROUNDING_FIXED = `/**
 * Round a monetary amount to 2 decimal places (half-up).
 * Used by invoice and tax calculations.
 *
 * Binary floats like 2.675 are stored as 2.674999…, so naive
 * Math.round(value * 100) / 100 rounds the wrong way. Parsing the
 * decimal string form ("2.675e2" → 267.5) sidesteps the artefact.
 */
function roundTo2(value) {
  const scaled = Math.round(Number(value + "e2"));
  return Number(scaled + "e-2");
}

module.exports = { roundTo2 };`;

export function buildRecoveryScript(): E[] {
  return [
    state("Mission opened", [
      { key: "mission", value: "Repair red suite on main (pricing-service)" },
      { key: "repo", value: "pricing-service @ main — 1 of 3 tests FAILING" },
      { key: "phase", value: "planning" },
    ]),
    {
      agent: "shogun",
      type: "plan",
      title: "Triage — objectives & acceptance criteria",
      detail: {
        objectives: [
          "Make the failing test suite green again",
          "Repair the rounding behaviour — do NOT change or delete tests",
        ],
        acceptanceCriteria: [
          "AC1: roundTo2(2.675) === 2.68 (half-up, not banker's rounding)",
          "AC2: roundTo2(1.005) === 1.01",
          "AC3: already-rounded values (19.99) stay stable",
          "AC4: full suite green, tests untouched (git diff must not modify tests/)",
        ],
        risks: ["Floating-point repair must not silently switch to banker's rounding for .5 cases"],
      },
    },
    tool("shogun", "run_tests", "npm test (baseline)", "3 tests, 2 passed, 1 FAILED: 'rounds up at the third decimal (half-up)' — AssertionError: 2.675 → 2.67, expected 2.68"),
    tool("shogun", "read_file", "tests/rounding.test.js", "Read 17 lines. Failure is in the half-up expectations for classic binary-float traps (2.675, 1.005)."),
    tasks("Task board updated — repair delegated", TASKS_RECOVERY),
    msg(
      "shogun",
      "samurai",
      "Task T3: repair roundTo2 (evidence attached)",
      "The failing assertions are the classic binary-float traps: Math.round(2.675*100)/100 → 2.67 because 2.675 is stored as 2.674999…. Fix the implementation so both 2.675 → 2.68 and 1.005 → 1.01 hold. Constraint: do not modify tests/.",
      "baseline run, AC1–AC4"
    ),
    edit("src/rounding.js", ROUNDING_BEFORE, ROUNDING_ATTEMPT1),
    testEvent("tests/", "npm test", 2, 1, [
      "▶ tests/rounding.test.js",
      "  ✔ rounds simple decimals (1ms)",
      "  ✖ rounds up at the third decimal (half-up) (2ms)",
      "    AssertionError: roundTo2(1.005) → 1, expected 1.01",
      "      (2.675 case now passes)",
      "  ✔ keeps already-rounded values stable (0ms)",
      "ℹ 2 tests passed, 1 failed (0.3s)",
    ], "fail"),
    msg(
      "sentinel",
      "samurai",
      "Still RED — new evidence from run #2",
      "Progress, but not fixed: toFixed repaired 2.675 → 2.68 yet 1.005 still fails (toFixed gives '1.00' because 1.005 is stored as 1.004999…). Conclusion: any approach based on the binary float value itself is unreliable here. Suggest a representation-based approach (e.g. parse the decimal string with an exponent) instead of float arithmetic.",
      "run #2 output"
    ),
    tasks("Task board updated — T4 feedback loop active", TASKS_RECOVERY.map((t) => (t.id === "T3" ? { ...t, status: "reopened" } : t.id === "T4" ? { ...t, status: "in_progress" } : t))),
    tool("samurai", "search_repo", "pattern=\"toFixed|Math.round\"", "2 prior approaches in repo history rely on float arithmetic — confirms Sentinel's analysis. Trying string-exponent strategy."),
    edit("src/rounding.js", ROUNDING_ATTEMPT1, ROUNDING_FIXED),
    testEvent("tests/", "npm test", 3, 0, [
      "▶ tests/rounding.test.js",
      "  ✔ rounds simple decimals (1ms)",
      "  ✔ rounds up at the third decimal (half-up) (1ms)",
      "    roundTo2(2.675) → 2.68 ✓   roundTo2(1.005) → 1.01 ✓",
      "  ✔ keeps already-rounded values stable (0ms)",
      "ℹ 3 tests passed, 0 failed (0.3s)",
    ], "pass"),
    msg("sentinel", "shogun", "Suite GREEN — 3/3 after repair round 2", "Feedback loop closed: run #1 (baseline) RED → run #2 RED with narrowed diagnosis → run #3 GREEN. Evidence chain in run log."),
    tasks("Task board updated", TASKS_RECOVERY.map((t) => (t.id === "T3" || t.id === "T4" ? { ...t, status: "done" } : t.id === "T5" ? { ...t, status: "in_progress" } : t))),
    verify([
      { criterion: "AC1: roundTo2(2.675) === 2.68", result: "pass", evidence: "assertion green in run #3" },
      { criterion: "AC2: roundTo2(1.005) === 1.01", result: "pass", evidence: "assertion green in run #3" },
      { criterion: "AC3: 19.99 stays stable", result: "pass", evidence: "assertion green in run #3" },
      { criterion: "AC4: tests/ untouched by the diff", result: "pass", evidence: "git diff touches only src/rounding.js" },
    ], "pass"),
    {
      agent: "shadow",
      type: "review",
      title: "Code review — approved with a question, answered by evidence",
      detail: {
        findings: [
          { severity: "info", note: "String-exponent trick is subtle but the JSDoc explains WHY — acceptable." },
          { severity: "warning", note: "Question: does it handle values ≥ 1e21 (where JS switches to exponential notation)?" },
          { severity: "info", note: "Answer from evidence: out of scope — amounts are finite decimals from invoice inputs; documented as a known limit instead of over-engineering." },
        ],
        verdict: "approve",
      },
    },
    {
      agent: "shadow",
      type: "security",
      title: "Security inspection — no issues found",
      detail: { findings: [] as { severity: string; note: string }[], verdict: "clean" },
    },
    tasks("Task board updated", TASKS_RECOVERY.map((t) => ({ ...t, status: "done" }))),
    approval({
      summary:
        "roundTo2 repaired via decimal string-exponent parsing after two failed float-arithmetic strategies. Feedback loop: baseline RED → attempt 1 RED (narrowed diagnosis from Sentinel) → attempt 2 GREEN. Tests untouched.",
      changedFiles: ["src/rounding.js"],
      checks: [
        { label: "Tests 3/3 green (was 2/3)", ok: true },
        { label: "Acceptance criteria verified", ok: true },
        { label: "Code review approved", ok: true },
        { label: "Security scan clean", ok: true },
      ],
      attempt: 1,
    }),
  ];
}

// ═════════════════════════════════════════════════════════════════════════════
// SCENARIO: security — notify-api, planted hardcoded credential
// ═════════════════════════════════════════════════════════════════════════════

const TASKS_SECURITY: Record<string, string>[] = [
  { id: "T1", title: "Analyse open-sourcing goal → audit criteria", assignee: "shogun", status: "done" },
  { id: "T2", title: "Security inspection of the whole tree (Shadow Council)", assignee: "shadow", status: "pending" },
  { id: "T3", title: "Remediate critical finding(s)", assignee: "samurai", status: "pending" },
  { id: "T4", title: "Re-scan + suite must stay green", assignee: "sentinel", status: "pending" },
  { id: "T5", title: "Independent verification of remediation", assignee: "verifier", status: "pending" },
];

const CONFIG_BEFORE = `// Service configuration
module.exports = {
  port: process.env.PORT || 8080,
  provider: {
    // TODO: move this out before open-sourcing
    apiKey: "sk_live_51H8xQp2ZmNkVJt9WqLrB3Yf",
    endpoint: "https://api.mailprovider.example/v1/send",
  },
  rateLimit: { windowMs: 60000, max: 100 },
};`;

const CONFIG_AFTER = `// Service configuration
// Secrets are read from the environment — never hardcode credentials.
function requireEnv(name) {
  const v = process.env[name];
  if (!v) {
    throw new Error(\`Missing required env var: \${name}. See .env.example\`);
  }
  return v;
}

module.exports = {
  port: process.env.PORT || 8080,
  provider: {
    apiKey: requireEnv("MAIL_PROVIDER_API_KEY"),
    endpoint: "https://api.mailprovider.example/v1/send",
  },
  rateLimit: { windowMs: 60000, max: 100 },
};`;

const ENV_EXAMPLE = `# Copy to .env and fill in real values. .env must stay git-ignored.
MAIL_PROVIDER_API_KEY=your-key-here`;

export function buildSecurityScript(): E[] {
  return [
    state("Mission opened", [
      { key: "mission", value: "Security pass before open-sourcing notify-api" },
      { key: "repo", value: "notify-api @ main (private → public)" },
      { key: "phase", value: "planning" },
    ]),
    {
      agent: "shogun",
      type: "plan",
      title: "Requirement analysis — audit scope",
      detail: {
        objectives: [
          "Find and remediate anything that would be unsafe to publish in a public repo",
          "Keep the service behaviour unchanged for legitimate configuration",
        ],
        acceptanceCriteria: [
          "AC1: no credentials, tokens or keys in source files",
          "AC2: missing-configuration fails loudly at startup, not silently",
          "AC3: existing test suite still passes",
          "AC4: security re-scan reports zero critical findings",
        ],
        risks: ["Deleting a secret from code does not un-leak it — key rotation is a human action outside the sandbox"],
      },
    },
    tool("shogun", "search_repo", "pattern=\"(?i)(api[_-]?key|secret|token|password)\\s*[:=]\"", "3 matches in src/config.js, 1 benign match in tests/"),
    tasks("Task board updated — audit delegated to Shadow Council", TASKS_SECURITY),
    msg("shogun", "shadow", "Task T2: full security inspection", "Repo goes public on Friday. Scan for: hardcoded secrets, unsafe operations, injection risks, unsafe defaults. Severity-ranked findings please.", "AC1–AC4"),
    tool("shadow", "security_scan", "tree-wide: secret patterns + entropy check", "1 CRITICAL, 0 WARNING. src/config.js:6 — hardcoded live API key 'sk_live_51H8xQ…' (high entropy, 'sk_live_' prefix)."),
    {
      agent: "shadow",
      type: "security",
      title: "Security findings — 1 CRITICAL",
      detail: {
        findings: [
          {
            severity: "critical",
            file: "src/config.js:6",
            issue: "Live provider API key hardcoded in source. Will be exposed the moment the repo becomes public — bots scrape GitHub for 'sk_live_' within minutes.",
            remediation: "Read from environment with fail-loud startup check; add .env.example; rotate the key (human action — code deletion cannot un-leak it).",
          },
        ],
        verdict: "blocked — must remediate before publish",
      },
    },
    tasks("Task board updated", TASKS_SECURITY.map((t) => (t.id === "T2" ? { ...t, status: "done" } : t.id === "T3" ? { ...t, status: "in_progress" } : t))),
    msg(
      "shadow",
      "samurai",
      "CRITICAL: hardcoded API key — remediation required",
      "src/config.js:6 contains a live credential. Implement env-based loading with a fail-loud requireEnv() helper and add .env.example. NOTE for the Shogun: this key must also be rotated at the provider — code changes alone are insufficient.",
      "security finding SEC-001"
    ),
    edit("src/config.js", CONFIG_BEFORE, CONFIG_AFTER),
    edit(".env.example (new file)", "// file did not exist", ENV_EXAMPLE),
    testEvent("tests/", "npm test", 1, 0, [
      "▶ tests/webhook.test.js",
      "  ✔ renders placeholders in the notification (2ms)",
      "ℹ 1 test passed, 0 failed (0.2s)",
    ], "pass"),
    tool("shadow", "security_scan", "re-scan after remediation", "0 CRITICAL, 0 WARNING. No secret-shaped strings remain in the tree. .env.example contains a placeholder only."),
    tasks("Task board updated", TASKS_SECURITY.map((t) => ({ ...t, status: "done" }))),
    verify([
      { criterion: "AC1: no credentials in source", result: "pass", evidence: "re-scan clean; config.js reads MAIL_PROVIDER_API_KEY from env" },
      { criterion: "AC2: missing config fails loudly", result: "pass", evidence: "requireEnv() throws at startup with pointer to .env.example" },
      { criterion: "AC3: suite still green", result: "pass", evidence: "run after remediation: 1/1 passed" },
      { criterion: "AC4: re-scan zero critical findings", result: "pass", evidence: "shadow council re-scan report in run log" },
    ], "pass"),
    {
      agent: "shadow",
      type: "review",
      title: "Code review — approved",
      detail: {
        findings: [
          { severity: "info", note: "Fail-loud startup check is the right call — silent empty-string keys are a classic outage cause." },
        ],
        verdict: "approve",
      },
    },
    approval({
      summary:
        "Shadow Council found 1 CRITICAL: live API key hardcoded in src/config.js. Remediated with env-based loading + fail-loud check + .env.example. Re-scan clean, suite green, verification passed.",
      changedFiles: ["src/config.js", ".env.example (new)"],
      checks: [
        { label: "Security re-scan clean", ok: true },
        { label: "Tests 1/1 green", ok: true },
        { label: "Acceptance criteria verified", ok: true },
        { label: "Code review approved", ok: true },
      ],
      attempt: 1,
      question:
        "The leaked key must also be rotated at the provider — deleting it from code cannot un-leak it. Approve applying the code fix once you accept that follow-up responsibility?",
    }),
  ];
}

// ═════════════════════════════════════════════════════════════════════════════
// SCENARIO: ambiguity — vague request → clarification loop with the human
// ═════════════════════════════════════════════════════════════════════════════

export function buildAmbiguityScript(): E[] {
  return [
    state("Mission opened", [
      { key: "mission", value: '"Make the search feature better."' },
      { key: "repo", value: "shopsearch @ main (clean tree)" },
      { key: "phase", value: "planning" },
    ]),
    {
      agent: "shogun",
      type: "plan",
      title: "Requirement analysis — BLOCKED: requirement is ambiguous",
      detail: {
        objectives: ["❌ Cannot be derived: 'better' has no measurable target"],
        acceptanceCriteria: [
          "AC-candidates are unbounded: sorting? relevance? fuzzy matching? pagination? performance?",
          "Building the wrong interpretation wastes the whole mission — bounded autonomy says STOP",
        ],
        risks: [
          "Ambiguity rule: when acceptance criteria cannot be stated, escalate to the human instead of guessing",
        ],
      },
    },
    tool("shogun", "search_repo", "pattern=\"TODO|FIXME|enhancement\"", "1 match: src/search.js — no recorded enhancement backlog to disambiguate the request."),
    msg("shogun", "human", "Clarification required before planning", "The request 'make search better' cannot be turned into testable acceptance criteria. I will not guess — please choose a concrete direction (or provide your own).", "bounded-autonomy rule 2"),
    approval({
      summary: "The Shogun stopped the mission instead of guessing: 'make search better' is not testable. Choose the concrete improvement to implement.",
      changedFiles: [],
      checks: [{ label: "Ambiguity detected — no code written", ok: true }],
      attempt: 1,
      question: "What does 'better' mean for shopsearch?",
      options: [
        "Sort results by relevance (name match quality), then price",
        "Add pagination (limit + offset) to the results",
        "Add fuzzy matching for typos (e.g. 'paly5' still finds PS5)",
      ],
    }),
  ];
}

export function buildAmbiguityTail(option: string): E[] {
  const isSort = option.toLowerCase().includes("sort");
  const isPage = option.toLowerCase().includes("pagination");
  const isFuzzy = option.toLowerCase().includes("fuzzy");

  const SEARCH_BEFORE = `function searchProducts(query, { limit = 20 } = {}) {
  if (typeof query !== "string") return [];

  const q = query.trim().toLowerCase();

  // Guard: ignore very short queries to protect performance
  if (q.length > MIN_QUERY_LENGTH) {
    const hits = CATALOG.filter((p) => p.name.toLowerCase().includes(q));
    return hits.slice(0, limit);
  }

  return [];
}`;

  const SEARCH_AFTER_SORT = `function searchProducts(query, { limit = 20 } = {}) {
  if (typeof query !== "string") return [];

  const q = query.trim().toLowerCase();

  // Guard: ignore very short queries to protect performance.
  // Queries of exactly MIN_QUERY_LENGTH chars are valid (e.g. "ps5").
  if (q.length >= MIN_QUERY_LENGTH) {
    const hits = CATALOG.filter((p) => p.name.toLowerCase().includes(q));
    // Relevance: longest match first (prefix > substring), then price.
    return hits
      .sort((a, b) => {
        const aStarts = a.name.toLowerCase().startsWith(q) ? 0 : 1;
        const bStarts = b.name.toLowerCase().startsWith(q) ? 0 : 1;
        return aStarts - bStarts || a.price - b.price;
      })
      .slice(0, limit);
  }

  return [];
}`;

  const SEARCH_AFTER_PAGE = `function searchProducts(query, { limit = 20, offset = 0 } = {}) {
  if (typeof query !== "string") return [];

  const q = query.trim().toLowerCase();

  // Guard: ignore very short queries to protect performance.
  // Queries of exactly MIN_QUERY_LENGTH chars are valid (e.g. "ps5").
  if (q.length >= MIN_QUERY_LENGTH) {
    const hits = CATALOG.filter((p) => p.name.toLowerCase().includes(q));
    return hits.slice(offset, offset + limit);
  }

  return [];
}`;

  const SEARCH_AFTER_FUZZY = `function searchProducts(query, { limit = 20 } = {}) {
  if (typeof query !== "string") return [];

  const q = query.trim().toLowerCase();

  // Guard: ignore very short queries to protect performance.
  if (q.length >= MIN_QUERY_LENGTH) {
    const hits = CATALOG.filter((p) => p.name.toLowerCase().includes(q));
    if (hits.length > 0) return hits.slice(0, limit);
    // Fuzzy fallback: all query characters appear in order (subsequence match)
    return CATALOG.filter((p) => isSubsequence(q, p.name.toLowerCase())).slice(0, limit);
  }

  return [];
}

function isSubsequence(q, name) {
  let i = 0;
  for (const ch of name) {
    if (ch === q[i]) i++;
    if (i === q.length) return true;
  }
  return false;
}`;

  const after = isSort ? SEARCH_AFTER_SORT : isPage ? SEARCH_AFTER_PAGE : SEARCH_AFTER_FUZZY;
  const newTest = isSort
    ? `test("sorts prefix matches before substring matches", () => {
  const hits = searchProducts("deck");
  assert.equal(hits[0].name, "Steam Deck 512GB");
});`
    : isPage
      ? `test("paginates results with offset", () => {
  const page1 = searchProducts("ps5", { limit: 1, offset: 0 });
  const page2 = searchProducts("ps5", { limit: 1, offset: 1 });
  assert.equal(page1.length, 1);
  assert.equal(page2.length, 1);
  assert.notEqual(page1[0].id, page2[0].id);
});`
      : `test("fuzzy: 'paly5' still finds PS5 products", () => {
  const hits = searchProducts("paly5");
  assert.equal(hits.length, 2);
});`;

  return [
    state("Shared state updated", [
      { key: "phase", value: "re-planning" },
      { key: "decision", value: option },
      { key: "note", value: "Requirement no longer ambiguous — plan revised" },
    ]),
    {
      agent: "shogun",
      type: "plan",
      title: "Plan revised v2 — based on the Daimyō's answer",
      detail: {
        objectives: [option],
        acceptanceCriteria: isSort
          ? ["AC1: prefix matches rank before substring matches", "AC2: ties broken by price", "AC3: full suite green"]
          : isPage
            ? ["AC1: offset+limit paginate results without duplication", "AC2: default behaviour (no params) unchanged", "AC3: full suite green"]
            : ["AC1: 'paly5' still finds both PS5 products", "AC2: exact matches take priority over fuzzy", "AC3: full suite green"],
        risks: ["Behaviour change is additive — existing tests must stay untouched and green"],
      },
    },
    msg("shogun", "samurai", "Task assigned: implement the clarified requirement", `Implement exactly this scope: ${option}. Keep the change minimal and consistent with the existing module style.`, "plan v2"),
    edit("src/search.js", SEARCH_BEFORE, after),
    edit("tests/search.test.js", `// (existing tests unchanged)`, `// (existing tests unchanged)\n${newTest}`),
    testEvent("tests/", "npm test", 3, 0, [
      "▶ tests/search.test.js",
      "  ✔ finds products by full name (2ms)",
      "  ✔ returns empty for very short queries (0ms)",
      `  ✔ ${isSort ? "sorts prefix matches before substring matches" : isPage ? "paginates results with offset" : "fuzzy: 'paly5' still finds PS5 products"} (1ms)`,
      "ℹ 3 tests passed, 0 failed (0.3s)",
    ], "pass"),
    verify(
      (isSort
        ? [
            { criterion: "AC1: prefix matches rank first", result: "pass", evidence: "new test green: 'deck' → Steam Deck first" },
            { criterion: "AC2: ties by price", result: "pass", evidence: "sort comparator verified in review of diff" },
            { criterion: "AC3: full suite green", result: "pass", evidence: "run: 3/3 passed" },
          ]
        : isPage
          ? [
              { criterion: "AC1: offset+limit paginate without duplication", result: "pass", evidence: "new test green: distinct ids across pages" },
              { criterion: "AC2: default behaviour unchanged", result: "pass", evidence: "existing 2 tests untouched and green" },
              { criterion: "AC3: full suite green", result: "pass", evidence: "run: 3/3 passed" },
            ]
          : [
              { criterion: "AC1: 'paly5' finds both PS5 products", result: "pass", evidence: "new fuzzy test green" },
              { criterion: "AC2: exact matches take priority", result: "pass", evidence: "fuzzy fallback only fires when exact filter is empty (diff reviewed)" },
              { criterion: "AC3: full suite green", result: "pass", evidence: "run: 3/3 passed" },
            ]
    ).map((c) => ({ ...c, result: c.result === "pass" ? "pass" : "fail" })),
      "pass"
    ),
    {
      agent: "shadow",
      type: "review",
      title: "Code review — approved",
      detail: {
        findings: [{ severity: "info", note: "Scope matches the clarified requirement exactly. No drive-by changes. Approved." }],
        verdict: "approve",
      },
    },
    approval({
      summary: `Implemented per your clarification: "${option}". Tests green (3/3), verification passed, review approved.`,
      changedFiles: ["src/search.js", "tests/search.test.js"],
      checks: [
        { label: "Tests 3/3 green", ok: true },
        { label: "Acceptance criteria verified", ok: true },
        { label: "Code review approved", ok: true },
      ],
      attempt: 1,
    }),
  ];
}

// ═════════════════════════════════════════════════════════════════════════════
// Rejection tails (bounded autonomy: 1 retry, then escalation)
// ═════════════════════════════════════════════════════════════════════════════

// ── Post-approval tail: apply the change & close the mission ────────────────

const CHANGED: Record<string, string[]> = {
  feature: ["src/validators/taskValidator.js (new)", "src/routes/tasks.js", "tests/tasks.test.js"],
  bug: ["src/search.js", "tests/search.test.js"],
  recovery: ["src/rounding.js"],
  security: ["src/config.js", ".env.example (new)"],
  ambiguity: ["src/search.js", "tests/search.test.js"],
};

const OUTCOMES: Record<string, string> = {
  feature:
    "VERIFIED COMPLETE — taskValidator module added and wired into POST /tasks. Evidence: suite 4/4 green, AC1–AC4 independently verified, review approved, security clean.",
  bug:
    "VERIFIED COMPLETE — off-by-one guard fixed (q.length >= MIN_QUERY_LENGTH) with regression test for issue #41. Evidence: red run #1 → green run #2, 3/3 green, AC1–AC3 verified.",
  recovery:
    "VERIFIED COMPLETE — roundTo2 repaired via decimal string-exponent parsing after a Sentinel feedback loop. Evidence: baseline RED → attempt1 RED → final GREEN 3/3, tests untouched (AC4).",
  security:
    "VERIFIED COMPLETE — hardcoded live API key removed, env-based loading with fail-loud startup, .env.example added. Evidence: re-scan clean, suite green, AC1–AC4 verified. NOTE: provider-side key rotation is a human action outside the sandbox.",
  ambiguity:
    "VERIFIED COMPLETE — vague request resolved through human clarification, then implemented to the clarified scope. Evidence: revised plan v2, suite 3/3 green, review approved.",
};

export function buildApplyTail(scenario: string, approvedOption?: string): E[] {
  const tail: E[] = [
    {
      agent: "human",
      type: "approval_decision",
      title: "Daimyō approved the change",
      detail: {
        decision: "approved",
        note: approvedOption || "Approved via Mission Control",
      },
    },
    {
      agent: "system",
      type: "apply",
      title: "Applying change to the working tree",
      detail: { changedFiles: CHANGED[scenario] || [] },
    },
    state("Mission state (final)", [
      { key: "status", value: "change applied & verified" },
      { key: "files", value: (CHANGED[scenario] || []).join(", ") },
      { key: "evidence", value: "all checks green — see run log" },
    ]),
    {
      agent: "system",
      type: "complete",
      title: "Mission complete — the guild delivers",
      detail: { outcome: OUTCOMES[scenario] || "Mission completed with evidence." },
    },
  ];
  return tail;
}

export function buildRejectionTail(attempt: number, reason: string): E[] {
  if (attempt >= 2) {
    return [
      msg("shogun", "human", "Escalation: mission stopped after repeated rejection", "The change was rejected twice. Per bounded-autonomy rules I am stopping instead of looping. Mission state preserved for inspection.", "iteration limit"),
      state("Mission state (final)", [
        { key: "status", value: "escalated to human — no change applied" },
        { key: "reason", value: reason || "rejected by overseer" },
        { key: "repo", value: "unchanged (all proposed diffs discarded)" },
      ]),
      {
        agent: "system",
        type: "complete",
        title: "Mission closed — escalated to human",
        detail: {
          outcome:
            "Escalated after repeated human rejection. Per bounded autonomy: iteration limit reached, no change was applied, repo left untouched. All evidence remains in the run log.",
        },
      },
    ];
  }
  return [
    state("Shared state updated", [
      { key: "status", value: "change rejected — NOT applied" },
      { key: "rejects", value: String(attempt) },
      { key: "reason", value: reason || "no reason given" },
    ]),
    msg("shogun", "samurai", "Human rejected the change — revise", `Reason: "${reason || "no reason given"}". Address the concern, keep scope identical, and resubmit. One retry is budgeted.`, "reject feedback"),
    {
      agent: "samurai",
      type: "review",
      title: "Samurai addressed the rejection feedback",
      detail: {
        findings: [
          { severity: "info", note: `Revised the change in response to: "${reason || "no reason given"}". Diffs updated; no new files added.` },
        ],
        verdict: "revised",
      },
    },
    testEvent("tests/", "npm test (re-run after revision)", 3, 0, [
      "▶ re-running affected suite after revision…",
      "ℹ 3 tests passed, 0 failed (0.3s)",
    ], "pass"),
    approval({
      summary: "Revised per your feedback and re-verified: suite green, criteria re-checked. This is the second and final approval attempt.",
      changedFiles: ["(revised diff — see run log)"],
      checks: [
        { label: "Tests green after revision", ok: true },
        { label: "Reviewer re-approved", ok: true },
      ],
      attempt: attempt + 1,
    }),
  ];
}
