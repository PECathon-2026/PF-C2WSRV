import type { MissionScenario, VirtualRepo } from "./types";

// ── Virtual demo repositories ────────────────────────────────────────────────
// Small controlled repos matching the PECathon evaluation scenarios.
// Each contains the seeded defect / vulnerability the guild must handle.

const KANBAN_FILES = [
  {
    path: "package.json",
    content: `{
  "name": "kanban-api",
  "version": "1.2.0",
  "scripts": { "test": "node --test tests/" }
}`,
  },
  {
    path: "src/routes/tasks.js",
    content: `const express = require("express");
const router = express.Router();
const store = require("../store");

// POST /tasks — create a task
router.post("/tasks", (req, res) => {
  const { title, priority } = req.body;
  if (!title || typeof title !== "string") {
    return res.status(400).json({ error: "title is required" });
  }
  const task = store.add({ title: title.trim(), priority: priority || "normal" });
  res.status(201).json(task);
});

// GET /tasks — list tasks
router.get("/tasks", (req, res) => {
  res.json(store.list());
});

module.exports = router;`,
  },
  {
    path: "src/store.js",
    content: `// In-memory task store
const tasks = [];
let nextId = 1;

module.exports = {
  add({ title, priority }) {
    const task = { id: nextId++, title, priority, createdAt: new Date().toISOString() };
    tasks.push(task);
    return task;
  },
  list() {
    return tasks;
  },
};`,
  },
  {
    path: "tests/tasks.test.js",
    content: `const { test } = require("node:test");
const assert = require("node:assert");

test("creates a task with a title", () => {
  const store = require("../src/store");
  const task = store.add({ title: "Write README", priority: "normal" });
  assert.equal(task.title, "Write README");
});

test("list returns created tasks", () => {
  const store = require("../src/store");
  assert.ok(Array.isArray(store.list()));
});`,
  },
];

const SHOPSEARCH_FILES = [
  {
    path: "package.json",
    content: `{
  "name": "shopsearch",
  "version": "0.8.3",
  "scripts": { "test": "node --test tests/" }
}`,
  },
  {
    path: "src/search.js",
    content: `const CATALOG = require("./catalog");

const MIN_QUERY_LENGTH = 3;

/**
 * Search products by name. Case-insensitive substring match.
 */
function searchProducts(query, { limit = 20 } = {}) {
  if (typeof query !== "string") return [];

  const q = query.trim().toLowerCase();

  // Guard: ignore very short queries to protect performance
  if (q.length > MIN_QUERY_LENGTH) {
    const hits = CATALOG.filter((p) => p.name.toLowerCase().includes(q));
    return hits.slice(0, limit);
  }

  return [];
}

module.exports = { searchProducts, MIN_QUERY_LENGTH };`,
  },
  {
    path: "src/catalog.js",
    content: `// Product catalogue (fixture)
module.exports = [
  { id: 1, name: "PlayStation 5 Console", price: 499 },
  { id: 2, name: "PS5 DualSense Controller", price: 69 },
  { id: 3, name: "Nintendo Switch OLED", price: 349 },
  { id: 4, name: "Steam Deck 512GB", price: 529 },
  { id: 5, name: "Gaming Headset Pro", price: 89 },
];`,
  },
  {
    path: "tests/search.test.js",
    content: `const { test } = require("node:test");
const assert = require("node:assert");
const { searchProducts } = require("../src/search");

test("finds products by full name", () => {
  const hits = searchProducts("PlayStation");
  assert.equal(hits.length, 1);
  assert.equal(hits[0].id, 1);
});

test("returns empty for very short queries", () => {
  assert.deepEqual(searchProducts("a"), []);
});`,
  },
];

const PRICING_FILES = [
  {
    path: "package.json",
    content: `{
  "name": "pricing-service",
  "version": "2.1.0",
  "scripts": { "test": "node --test tests/" }
}`,
  },
  {
    path: "src/rounding.js",
    content: `/**
 * Round a monetary amount to 2 decimal places (half-up).
 * Used by invoice and tax calculations.
 */
function roundTo2(value) {
  return Math.round(value * 100) / 100;
}

module.exports = { roundTo2 };`,
  },
  {
    path: "tests/rounding.test.js",
    content: `const { test } = require("node:test");
const assert = require("node:assert");
const { roundTo2 } = require("../src/rounding");

test("rounds simple decimals", () => {
  assert.equal(roundTo2(2.5), 2.5);
  assert.equal(roundTo2(2.34), 2.34);
});

test("rounds up at the third decimal (half-up)", () => {
  assert.equal(roundTo2(2.675), 2.68);   // FAILS: binary float gives 2.67
  assert.equal(roundTo2(1.005), 1.01);   // FAILS: binary float gives 1.0
});

test("keeps already-rounded values stable", () => {
  assert.equal(roundTo2(19.99), 19.99);
});`,
  },
];

const NOTIFY_FILES = [
  {
    path: "package.json",
    content: `{
  "name": "notify-api",
  "version": "0.4.1",
  "private": true,
  "scripts": { "test": "node --test tests/" }
}`,
  },
  {
    path: "src/config.js",
    content: `// Service configuration
module.exports = {
  port: process.env.PORT || 8080,
  provider: {
    // TODO: move this out before open-sourcing
    apiKey: "sk_live_51H8xQp2ZmNkVJt9WqLrB3Yf",
    endpoint: "https://api.mailprovider.example/v1/send",
  },
  rateLimit: { windowMs: 60000, max: 100 },
};`,
  },
  {
    path: "src/webhook.js",
    content: `const { renderTemplate } = require("./render");

/**
 * Build the notification body for a webhook event.
 */
function buildNotification(event) {
  const title = renderTemplate(event.title, event.payload);
  const body = renderTemplate(event.body, event.payload);
  return { title, body, priority: event.priority || "normal" };
}

module.exports = { buildNotification };`,
  },
  {
    path: "src/render.js",
    content: `/**
 * Tiny template renderer: replaces {{key}} placeholders.
 */
function renderTemplate(template, payload = {}) {
  return String(template).replace(/{{\\s*([a-zA-Z0-9_.]+)\\s*}}/g, (_, key) => {
    const v = payload[key];
    return v === undefined ? "" : String(v);
  });
}

module.exports = { renderTemplate };`,
  },
  {
    path: "tests/webhook.test.js",
    content: `const { test } = require("node:test");
const assert = require("node:assert");
const { buildNotification } = require("../src/webhook");

test("renders placeholders in the notification", () => {
  const n = buildNotification({
    title: "Payment received",
    body: "Hi {{name}}, you paid {{amount}} EUR",
    payload: { name: "Aiko", amount: "42.50" },
  });
  assert.equal(n.body, "Hi Aiko, you paid 42.50 EUR");
});`,
  },
];

export const REPOS: Record<Exclude<MissionScenario, "custom">, VirtualRepo> = {
  feature: {
    name: "kanban-api",
    language: "Node.js / Express",
    description: "Small task-management API. 3 source files, 1 test file, all tests green.",
    files: KANBAN_FILES,
  },
  bug: {
    name: "shopsearch",
    language: "Node.js",
    description: "Product search service. A seeded off-by-one defect hides in src/search.js.",
    files: SHOPSEARCH_FILES,
  },
  recovery: {
    name: "pricing-service",
    language: "Node.js",
    description: "Money-math service. The test suite on main is RED: 1 of 4 tests failing.",
    files: PRICING_FILES,
  },
  security: {
    name: "notify-api",
    language: "Node.js",
    description: "Notification microservice about to be open-sourced. Contains a planted vulnerability.",
    files: NOTIFY_FILES,
  },
  ambiguity: {
    name: "shopsearch",
    language: "Node.js",
    description: "Product search service. The incoming requirement is deliberately vague.",
    files: SHOPSEARCH_FILES,
  },
};

export function findFile(repo: VirtualRepo, path: string) {
  return repo.files.find((f) => f.path === path);
}
