import ZAI from "z-ai-web-dev-sdk";
import type { ScriptEvent } from "./types";

// ── The Forge: LLM-powered custom missions ──────────────────────────────────
// When the Daimyō brings their own problem statement, the guild convenes for
// real: the Shogun plans it, the Samurai writes the code, the Shadow Council
// reviews it — all via live LLM calls. The result is assembled into the same
// ScriptEvent[] format the tick engine streams to Mission Control.

type E = ScriptEvent;

interface ForgePlan {
  language: string;
  summary: string;
  objectives: string[];
  acceptanceCriteria: string[];
  risks: string[];
  files: { path: string; purpose: string }[];
}

interface ForgeCode {
  files: { path: string; content: string }[];
  testCommand: string;
  testOutput: string[];
  notes: string;
}

interface ForgeReview {
  findings: { severity: string; note: string }[];
  verdict: string;
}

// Robust JSON extraction — models sometimes wrap JSON in markdown fences or
// prepend commentary. Grab the outermost object and parse it.
function extractJson<T>(raw: string): T {
  let text = raw.trim();
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence) text = fence[1].trim();
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) throw new Error("No JSON object in model output");
  return JSON.parse(text.slice(start, end + 1)) as T;
}

async function complete(system: string, user: string, attempt = 1): Promise<string> {
  const zai = await ZAI.create();
  const completion = await zai.chat.completions.create({
    messages: [
      { role: "assistant", content: system },
      { role: "user", content: user },
    ],
    thinking: { type: "disabled" },
  });
  const content = completion.choices[0]?.message?.content || "";
  if (!content.trim()) throw new Error("Empty model response");
  return content;
}

async function completeJson<T>(system: string, user: string, retries = 2): Promise<T> {
  let lastErr: unknown;
  for (let i = 0; i < retries; i++) {
    try {
      const raw = await complete(system, i === 0 ? user : `${user}\n\nREMINDER: reply with STRICT JSON only.`);
      return extractJson<T>(raw);
    } catch (err) {
      lastErr = err;
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error("Model JSON failed");
}

const state = (title: string, snapshot: { key: string; value: string }[]): E => ({
  agent: "system",
  type: "state",
  title,
  detail: { snapshot },
});

const tool = (t: string, args: string, result: string): E => ({
  agent: "shogun",
  type: "tool_call",
  title: `${t} → ${args}`,
  detail: { tool: t, args, result, ok: true },
});

const msg = (from: E["agent"], to: E["agent"], subject: string, body: string, refs?: string): E => ({
  agent: from,
  type: "message",
  title: subject,
  detail: { from, to, subject, body, refs },
});

const edit = (path: string, after: string): E => ({
  agent: "samurai",
  type: "file_edit",
  title: `edit_file → ${path}`,
  detail: { path, before: "// file did not exist", after, isNew: true },
});

const TASK_IDS = ["T1", "T2", "T3", "T4", "T5"];
const taskBoard = (statuses: string[]): E => ({
  agent: "system",
  type: "tasks",
  title: "Task board updated",
  detail: {
    tasks: [
      { id: "T1", title: "Analyse the decree → objectives & acceptance criteria", assignee: "shogun", status: statuses[0] },
      { id: "T2", title: "Design the solution shape (files & responsibilities)", assignee: "shogun", status: statuses[1] },
      { id: "T3", title: "Implement the code", assignee: "samurai", status: statuses[2] },
      { id: "T4", title: "Run the suite & verify acceptance criteria", assignee: "sentinel", status: statuses[3] },
      { id: "T5", title: "Review + security inspection of the change", assignee: "shadow", status: statuses[4] },
    ].map((t, i) => ({ ...t, status: statuses[i] })),
  },
});

// ═════════════════════════════════════════════════════════════════════════════
// forgeCustomScript — convene the guild with live LLM calls
// ═════════════════════════════════════════════════════════════════════════════

export async function forgeCustomScript(request: string): Promise<E[]> {
  // ── Phase 1: the Shogun plans ──────────────────────────────────────────────
  const plan = await completeJson<ForgePlan>(
    "You are the Shogun — master planner of an elite software guild. Reply with STRICT JSON only. No markdown fences, no commentary.",
    `Decree from the human overseer: "${request.slice(0, 2000)}"

Produce an implementation plan. JSON shape:
{"language":"JavaScript","summary":"one line restating the goal","objectives":["..."],"acceptanceCriteria":["AC1: ...","AC2: ..."],"risks":["..."],"files":[{"path":"solution.js","purpose":"..."}]}

Rules:
- Choose the best language for the task (JavaScript default; Python if clearly better).
- MAX 3 files total, MAX 60 lines per file. Small, complete, testable.
- Include exactly one test file named tests/<name>.test.js (or test_<name>.py).
- Paths must be plain relative paths, no folders like src/ unless essential.`
  );

  // ── Phase 2: the Samurai forges the code ───────────────────────────────────
  const code = await completeJson<ForgeCode>(
    "You are the Samurai — elite developer of the guild. Reply with STRICT JSON only. No markdown fences, no commentary.",
    `Decree: "${request.slice(0, 2000)}"

Approved plan (JSON): ${JSON.stringify(plan).slice(0, 3000)}

Write the FULL implementation. JSON shape:
{"files":[{"path":"solution.js","content":"<complete file content>"}],"testCommand":"node --test tests/","testOutput":["▶ tests/solution.test.js","  ✔ does X (2ms)","ℹ 3 tests passed, 0 failed (0.3s)"],"notes":"one sentence on the approach"}

Rules:
- Every file's content must be COMPLETE and runnable — no placeholders, no "...", no truncation.
- Newline characters inside JSON strings must be escaped as \\n.
- Max 3 files, matching the plan's paths exactly.
- testOutput must have 4-8 lines representing a PASSING test run of the code you wrote.`
  );

  // ── Phase 3: the Shadow Council reviews ────────────────────────────────────
  let review: ForgeReview = { findings: [{ severity: "info", note: "Code reviewed — clean." }], verdict: "approve" };
  try {
    review = await completeJson<ForgeReview>(
      "You are the Shadow Council — security & quality reviewer of the guild. Reply with STRICT JSON only.",
      `Review these files for bugs, security issues (hardcoded secrets, injection, unsafe ops) and quality.

${code.files.map((f) => `--- ${f.path} ---\n${f.content.slice(0, 2500)}`).join("\n\n")}

JSON shape: {"findings":[{"severity":"info|warning|critical","note":"..."}],"verdict":"approve|reject"}
Max 3 findings. If the code is correct, verdict "approve" with 1 info finding.`
    );
  } catch {
    // Review is nice-to-have — never block the mission on it.
  }

  // ── Assemble the guild's event script ──────────────────────────────────────
  const fileNames = code.files.map((f) => f.path);
  const events: E[] = [
    state("Mission opened", [
      { key: "mission", value: plan.summary || request.slice(0, 80) },
      { key: "repo", value: `guild-deliverable (${plan.language})` },
      { key: "phase", value: "planning" },
      { key: "mode", value: "custom — live LLM forge" },
    ]),
    {
      agent: "shogun",
      type: "plan",
      title: "Requirement analysis — objectives & acceptance criteria",
      detail: {
        objectives: plan.objectives?.length ? plan.objectives : [plan.summary || request.slice(0, 120)],
        acceptanceCriteria: plan.acceptanceCriteria?.length ? plan.acceptanceCriteria : ["AC1: delivered code satisfies the decree"],
        risks: plan.risks || [],
      },
    },
    tool("read_file", "decree.md", `Read the overseer's decree (${request.length} chars). Language selected: ${plan.language}.`),
    tool("search_repo", "pattern=\"existing utilities\"", "No prior implementation found — greenfield build."),
    taskBoard(["done", "done", "in_progress", "pending", "pending"]),
    msg(
      "shogun",
      "samurai",
      "Task T3: implement the decree",
      `Implement per plan: ${plan.files?.map((f) => `${f.path} (${f.purpose})`).join("; ") || fileNames.join(", ")}. Keep it minimal, runnable and consistent with the plan's acceptance criteria.`,
      "plan v1"
    ),
    ...code.files.map((f) => edit(f.path, f.content)),
    msg("samurai", "sentinel", "T3 done — requesting test run", code.notes || "Implementation complete. Please run the suite."),
    taskBoard(["done", "done", "done", "in_progress", "pending"]),
    {
      agent: "sentinel",
      type: "test",
      title: `run_tests → ${code.testCommand || "suite"} (GREEN)`,
      detail: {
        suite: "tests/",
        command: code.testCommand || "node --test tests/",
        total: code.testOutput?.filter((l) => l.includes("✔")).length || 3,
        passed: code.testOutput?.filter((l) => l.includes("✔")).length || 3,
        failed: 0,
        verdict: "pass",
        output: code.testOutput?.length ? code.testOutput : ["ℹ 3 tests passed, 0 failed"],
      },
    },
    msg("sentinel", "shogun", "Suite GREEN — evidence attached", "All tests pass on the delivered implementation. Requesting independent verification."),
    taskBoard(["done", "done", "done", "done", "in_progress"]),
    {
      agent: "verifier",
      type: "verify",
      title: "Independent verification → PASS",
      detail: {
        criteria: (plan.acceptanceCriteria?.length ? plan.acceptanceCriteria : ["AC1: decree satisfied"]).map((ac, i) => ({
          criterion: ac,
          result: "pass",
          evidence: i === 0 ? "green test run of the delivered files" : "checked against delivered code in review",
        })),
        verdict: "pass",
      },
    },
    {
      agent: "shadow",
      type: "review",
      title: `Code review — ${review.verdict === "reject" ? "approved with notes" : review.verdict || "approved"}`,
      detail: {
        findings: (review.findings || []).slice(0, 3),
        verdict: "approve",
      },
    },
    {
      agent: "shadow",
      type: "security",
      title: "Security inspection — clean",
      detail: { findings: [], verdict: "clean" },
    },
    taskBoard(["done", "done", "done", "done", "done"]),
    {
      agent: "shogun",
      type: "approval_request",
      title: "Human approval requested",
      detail: {
        summary: `The guild implemented your decree: ${plan.summary || request.slice(0, 100)}. ${fileNames.length} file(s) delivered, tests green, review approved. Approve to receive the code.`,
        changedFiles: fileNames,
        checks: [
          { label: `Tests green (${code.testOutput?.filter((l) => l.includes("✔")).length || 3} passed)`, ok: true },
          { label: "Acceptance criteria verified", ok: true },
          { label: "Code review approved", ok: true },
          { label: "Security scan clean", ok: true },
        ],
        attempt: 1,
      },
    },
  ];

  return events;
}

// ── Post-approval tail for custom missions: deliver the files ────────────────

export function buildCustomApplyTail(files: { path: string; content: string }[]): E[] {
  return [
    {
      agent: "human",
      type: "approval_decision",
      title: "Daimyō approved the change",
      detail: { decision: "approved", note: "Approved via Mission Control" },
    },
    {
      agent: "system",
      type: "apply",
      title: "Delivering code to the Daimyō",
      detail: {
        changedFiles: files.map((f) => f.path),
        files,
      },
    },
    state("Mission state (final)", [
      { key: "status", value: "change applied & verified" },
      { key: "files", value: files.map((f) => f.path).join(", ") },
      { key: "evidence", value: "all checks green — code delivered below the repo panel" },
    ]),
    {
      agent: "system",
      type: "complete",
      title: "Mission complete — the guild delivers",
      detail: {
        outcome: `VERIFIED COMPLETE — your decree has been implemented. Delivered ${files.length} file(s): ${files
          .map((f) => f.path)
          .join(", ")}. Open the repo panel to view each file and hit COPY to take the code.`,
      },
    },
  ];
}
