// ── DevPilot shared types ────────────────────────────────────────────────────
// Used by the engine (server) and the dashboard (client).

export type AgentId =
  | "shogun" // Planner  — The Shogun's Council
  | "samurai" // Developer — The Samurai Forge
  | "sentinel" // Tester — The Sentinel Dojo
  | "verifier" // Independent verification
  | "shadow" // Reviewer / Security — The Shadow Council
  | "human" // Human overseer
  | "system"; // Orchestration / mission state

export type MissionScenario = "feature" | "bug" | "recovery" | "security" | "ambiguity" | "custom";

export type MissionStatus =
  | "preparing" // LLM forge is generating the guild's script (custom missions)
  | "running"
  | "awaiting_approval"
  | "applying"
  | "completed"
  | "escalated";

export interface ScriptEvent {
  agent: AgentId;
  type: string;
  title: string;
  detail?: Record<string, unknown>;
}

export interface RepoFile {
  path: string;
  content: string;
}

export interface VirtualRepo {
  name: string;
  language: string;
  description: string;
  files: RepoFile[];
}

// ── Event detail payloads ────────────────────────────────────────────────────

export interface PlanDetail {
  objectives: string[];
  acceptanceCriteria: string[];
  risks?: string[];
}

export interface ReconDetail {
  filesScanned: string[];
  relevantFiles: string[];
  conventions: string[];
  risks: string[];
}

export interface TaskItem {
  id: string;
  title: string;
  assignee: AgentId;
  status: "pending" | "in_progress" | "done" | "blocked" | "reopened";
}

export interface TasksDetail {
  tasks: TaskItem[];
}

export interface ToolCallDetail {
  tool: "read_file" | "search_repo" | "edit_file" | "write_file" | "run_tests" | "security_scan" | "git_diff";
  args: string;
  result: string;
  ok: boolean;
}

export interface MessageDetail {
  from: AgentId;
  to: AgentId;
  subject: string;
  body: string;
  refs?: string;
}

export interface TestDetail {
  suite: string;
  command: string;
  total: number;
  passed: number;
  failed: number;
  verdict: "pass" | "fail";
  output: string[];
}

export interface DiffDetail {
  path: string;
  before: string;
  after: string;
}

export interface SecurityFindingDetail {
  severity: "critical" | "warning" | "info";
  file: string;
  issue: string;
  remediation: string;
}

export interface VerifyDetail {
  criteria: { criterion: string; result: "pass" | "fail" | "unverified"; evidence: string }[];
  verdict: "pass" | "fail";
}

export interface ApprovalDetail {
  summary: string;
  changedFiles: string[];
  checks: { label: string; ok: boolean }[];
  attempt: number;
  // for ambiguity clarification missions:
  options?: string[];
  question?: string;
}

export interface SharedStateDetail {
  snapshot: { key: string; value: string }[];
}

export const AGENT_META: Record<AgentId, { name: string; role: string; icon: string }> = {
  shogun: { name: "Shogun", role: "Planner & Orchestrator", icon: "crown" },
  samurai: { name: "Samurai", role: "Developer Agent", icon: "sword" },
  sentinel: { name: "Sentinel", role: "Test & Verification Runner", icon: "shield" },
  verifier: { name: "Apostle", role: "Independent Verifier", icon: "check" },
  shadow: { name: "Shadow Council", role: "Reviewer & Security", icon: "eye" },
  human: { name: "Daimyō (You)", role: "Human Overseer", icon: "user" },
  system: { name: "Mission State", role: "Shared Blackboard", icon: "scroll" },
};
