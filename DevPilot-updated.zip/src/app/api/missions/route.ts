import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { REPOS } from "@/lib/devpilot/repos";
import { forgeCustomScript } from "@/lib/devpilot/custom";
import {
  buildFeatureScript,
  buildBugScript,
  buildRecoveryScript,
  buildSecurityScript,
  buildAmbiguityScript,
} from "@/lib/devpilot/script";
import type { MissionScenario, ScriptEvent } from "@/lib/devpilot/types";

const SCENARIOS: MissionScenario[] = ["feature", "bug", "recovery", "security", "ambiguity", "custom"];

const DEFAULT_REQUESTS: Record<Exclude<MissionScenario, "custom">, string> = {
  feature:
    "Add input validation to POST /tasks: reject titles that are empty or longer than 80 characters, returning a 400 with a helpful message. Keep existing behaviour intact.",
  bug: "Users report that searching 'ps5' returns no results even though the products exist in the catalogue. Investigate and fix.",
  recovery:
    "npm test on main is red. Get the suite green again without weakening what the tests check.",
  security:
    "We open-source this repository on Friday. Do a security pass and fix anything critical before then.",
  ambiguity: "Make the search feature better.",
};

const SCRIPT_BUILDERS: Record<MissionScenario, () => ScriptEvent[]> = {
  feature: buildFeatureScript,
  bug: buildBugScript,
  recovery: buildRecoveryScript,
  security: buildSecurityScript,
  ambiguity: buildAmbiguityScript,
};

export async function GET() {
  const missions = await db.mission.findMany({
    orderBy: { createdAt: "desc" },
    take: 12,
    select: {
      id: true,
      scenario: true,
      request: true,
      repoName: true,
      status: true,
      outcome: true,
      createdAt: true,
    },
  });
  return NextResponse.json({ missions });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const scenario = (body?.scenario as MissionScenario) || "recovery";
  if (!SCENARIOS.includes(scenario)) {
    return NextResponse.json({ error: "Unknown scenario" }, { status: 400 });
  }
  const request =
    (typeof body?.request === "string" && body.request.trim().length > 0
      ? body.request.trim()
      : scenario === "custom" ? "" : DEFAULT_REQUESTS[scenario]);

  if (scenario === "custom") {
    if (!request) {
      return NextResponse.json(
        { error: "Describe your problem statement in the decree box first." },
        { status: 400 }
      );
    }
    // Custom mission: the guild convenes live (LLM forge) — create the shell
    // first so Mission Control can show "convening…", then fill the script.
    const mission = await db.mission.create({
      data: {
        scenario,
        request,
        repoName: "guild-deliverable",
        status: "preparing",
        script: [],
      },
    });

    // Fire-and-forget forge — the tick engine starts once status → running.
    void (async () => {
      try {
        const script = await forgeCustomScript(request);
        await db.mission.update({
          where: { id: mission.id },
          data: { script: script as unknown as object, status: "running" },
        });
      } catch (err) {
        await db.mission.update({
          where: { id: mission.id },
          data: {
            status: "escalated",
            outcome:
              "The guild could not convene — the AI forge failed or timed out. Try a shorter, clearer problem statement and launch again.",
          },
        });
        console.error("forge failed:", err);
      }
    })();

    return NextResponse.json({ missionId: mission.id });
  }

  const repo = REPOS[scenario as keyof typeof REPOS];
  const script = SCRIPT_BUILDERS[scenario as keyof typeof SCRIPT_BUILDERS]();

  const mission = await db.mission.create({
    data: {
      scenario,
      request,
      repoName: repo.name,
      status: "running",
      script: script as unknown as object,
    },
  });

  return NextResponse.json({ missionId: mission.id });
}
