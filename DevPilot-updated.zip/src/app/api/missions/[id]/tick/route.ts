import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import type { ScriptEvent } from "@/lib/devpilot/types";

const MIN_EVENT_INTERVAL_MS = 350;

/**
 * Advances the mission by one event ("tick" driven by the client poller —
 * the orchestrator emits one log entry at a time, like a real run).
 */
export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const mission = await db.mission.findUnique({ where: { id } });
  if (!mission) {
    return NextResponse.json({ error: "Mission not found" }, { status: 404 });
  }

  // Paused for the human gate — ticks have no effect until a decision lands.
  if (mission.status !== "running") {
    return NextResponse.json({ paused: true, status: mission.status });
  }

  // Pace emission so the log streams at a watchable speed.
  const since = Date.now() - new Date(mission.updatedAt).getTime();
  if (since < MIN_EVENT_INTERVAL_MS) {
    return NextResponse.json({ pacing: true, status: mission.status });
  }

  const script = mission.script as unknown as ScriptEvent[];
  if (mission.emitted >= script.length) {
    // Should not normally happen (complete event sets status), but stay safe.
    const updated = await db.mission.update({
      where: { id },
      data: {
        status: "completed",
        outcome:
          mission.outcome ||
          "Run log exhausted. All scripted events have been emitted.",
      },
    });
    return NextResponse.json({ status: updated.status });
  }

  const next = script[mission.emitted];
  await db.missionEvent.create({
    data: {
      missionId: id,
      seq: mission.emitted,
      agent: next.agent,
      type: next.type,
      title: next.title,
      detail: (next.detail ?? {}) as object,
    },
  });

  const data: { emitted: number; status?: string; outcome?: string } = {
    emitted: mission.emitted + 1,
  };

  if (next.type === "approval_request") {
    data.status = "awaiting_approval";
  }
  if (next.type === "complete") {
    data.status = "completed";
    const outcome = (next.detail as { outcome?: string })?.outcome;
    if (outcome) data.outcome = outcome;
  }

  const updated = await db.mission.update({ where: { id }, data });
  return NextResponse.json({ status: updated.status, emitted: updated.emitted });
}
