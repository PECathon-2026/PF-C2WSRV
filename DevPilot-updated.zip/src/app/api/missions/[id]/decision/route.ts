import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { buildCustomApplyTail } from "@/lib/devpilot/custom";
import {
  buildApplyTail,
  buildAmbiguityTail,
  buildRejectionTail,
} from "@/lib/devpilot/script";
import type { ScriptEvent } from "@/lib/devpilot/types";

const MAX_REJECTS = 2; // bounded autonomy: after 2 rejections the mission escalates

/**
 * Human decision at the approval gate.
 * body: { decision: "approve" | "reject", reason?: string, choice?: string }
 */
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const decision = body?.decision as "approve" | "reject";
  const reason = typeof body?.reason === "string" ? body.reason : "";
  const choice = typeof body?.choice === "string" ? body.choice : "";

  const mission = await db.mission.findUnique({ where: { id } });
  if (!mission) {
    return NextResponse.json({ error: "Mission not found" }, { status: 404 });
  }
  if (mission.status !== "awaiting_approval") {
    return NextResponse.json(
      { error: `Mission is not awaiting approval (status: ${mission.status})` },
      { status: 409 }
    );
  }

  const events = await db.missionEvent.findMany({
    where: { missionId: id, type: "approval_request" },
    select: { seq: true },
  });
  const approvalRound = events.length;

  const script = mission.script as unknown as ScriptEvent[];
  let tail: ScriptEvent[];
  let rejects = mission.rejects;

  if (decision === "approve") {
    if (mission.scenario === "ambiguity" && approvalRound === 1) {
      // First gate on the ambiguity scenario = requirement clarification.
      tail = buildAmbiguityTail(choice || "Sort results by relevance (name match quality), then price");
    } else if (mission.scenario === "custom") {
      // Deliver the generated files to the Daimyō.
      const edits = await db.missionEvent.findMany({
        where: { missionId: id, type: "file_edit" },
        orderBy: { seq: "asc" },
        select: { detail: true },
      });
      const files = new Map<string, string>();
      for (const e of edits) {
        const d = e.detail as { path?: string; after?: string } | null;
        if (d?.path && typeof d.after === "string") {
          files.set(d.path.replace(/ \(new file\)$/, ""), d.after);
        }
      }
      tail = buildCustomApplyTail(
        Array.from(files.entries()).map(([path, content]) => ({ path, content }))
      );
    } else {
      tail = buildApplyTail(mission.scenario, choice);
    }
  } else {
    rejects += 1;
    tail = buildRejectionTail(rejects, reason);
  }

  const updated = await db.mission.update({
    where: { id },
    data: {
      script: [...script, ...tail] as unknown as object,
      rejects,
      status: "running",
    },
  });

  return NextResponse.json({ status: updated.status, rejects: updated.rejects });
}
