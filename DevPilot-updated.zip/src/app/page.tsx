"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  ScrollText,
  Landmark,
  ClipboardCheck,
  Boxes,
  Rocket,
  Loader2,
  Moon,
} from "lucide-react";
import { EventCard } from "@/components/devpilot/event-card";
import { Architecture } from "@/components/devpilot/architecture";
import {
  SCENARIOS,
  ScenarioPicker,
  AgentRow,
  ApprovalGate,
  TaskBoard,
  SharedState,
  RepoViewer,
  History,
} from "@/components/devpilot/panels";
import type { MissionScenario } from "@/lib/devpilot/types";

type EventDTO = {
  id: number;
  seq: number;
  agent: string;
  type: string;
  title: string;
  detail: any;
  ts: string;
};

type MissionDTO = {
  id: string;
  scenario: MissionScenario;
  request: string;
  repoName: string;
  status: string;
  outcome: string | null;
  rejects: number;
  events: EventDTO[];
};

type Tab = "control" | "log" | "evidence" | "architecture";

// Custom torii gate mark (not in lucide) — the guild's crest
function ToriiMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" className={className} aria-hidden>
      <path d="M3 6c3-1.5 15-1.5 18 0" />
      <path d="M4.5 9.5h15" />
      <path d="M6 6.8V20" />
      <path d="M18 6.8V20" />
      <path d="M12 9.5V14" />
    </svg>
  );
}

const TABS: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "control", label: "Mission Control", icon: Boxes },
  { id: "log", label: "Run Log", icon: ScrollText },
  { id: "evidence", label: "Evidence", icon: ClipboardCheck },
  { id: "architecture", label: "Architecture", icon: Landmark },
];

export default function Page() {
  const [tab, setTab] = useState<Tab>("control");
  const [scenario, setScenario] = useState<MissionScenario>("recovery");
  const [request, setRequest] = useState(
    "npm test on main is red. Get the suite green again without weakening what the tests check."
  );
  const [launchError, setLaunchError] = useState<string | null>(null);
  const [mission, setMission] = useState<MissionDTO | null>(null);
  const [repo, setRepo] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [launching, setLaunching] = useState(false);
  const [deciding, setDeciding] = useState(false);
  const [agentFilter, setAgentFilter] = useState<string>("all");
  const logEndRef = useRef<HTMLDivElement | null>(null);

  const loadHistory = useCallback(async () => {
    try {
      const res = await fetch("/api/missions");
      if (res.ok) {
        const data = await res.json();
        setHistory(data.missions || []);
      }
    } catch {}
  }, []);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  // ── Live polling: advance the mission one event at a time ──────────────────
  const missionId = mission?.id ?? null;
  useEffect(() => {
    if (!missionId) return;
    let alive = true;

    const poll = async () => {
      try {
        const res = await fetch(`/api/missions/${missionId}`, { cache: "no-store" });
        if (!res.ok) return;
        const data = await res.json();
        if (!alive) return;
        setMission(data.mission);
        setRepo(data.repo);
        if (data.mission.status === "running") {
          await fetch(`/api/missions/${missionId}/tick`, { method: "POST" });
        }
      } catch {}
    };

    poll();
    const t = setInterval(poll, 1100);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [missionId]);

  // auto-scroll the run log
  useEffect(() => {
    if (tab === "log") logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [mission?.events?.length, tab]);

  const launch = async () => {
    setLaunching(true);
    setLaunchError(null);
    try {
      const res = await fetch("/api/missions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scenario, request }),
      });
      if (res.ok) {
        const data = await res.json();
        const mres = await fetch(`/api/missions/${data.missionId}`, { cache: "no-store" });
        const mdata = await mres.json();
        setMission(mdata.mission);
        setRepo(mdata.repo);
        loadHistory();
      } else {
        const err = await res.json().catch(() => ({}));
        setLaunchError(err.error || "Launch failed — try again.");
      }
    } finally {
      setLaunching(false);
    }
  };

  const selectMission = async (id: string) => {
    const res = await fetch(`/api/missions/${id}`, { cache: "no-store" });
    if (res.ok) {
      const data = await res.json();
      setMission(data.mission);
      setRepo(data.repo);
      setTab("control");
    }
  };

  const decide = async (d: "approve" | "reject", payload: { choice?: string; reason?: string }) => {
    if (!mission) return;
    setDeciding(true);
    try {
      await fetch(`/api/missions/${mission.id}/decision`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ decision: d, ...payload }),
      });
      const res = await fetch(`/api/missions/${mission.id}`, { cache: "no-store" });
      if (res.ok) {
        const data = await res.json();
        setMission(data.mission);
      }
    } finally {
      setDeciding(false);
    }
  };

  const onScenarioChange = (s: MissionScenario) => {
    setScenario(s);
    setLaunchError(null);
    const found = SCENARIOS.find((x) => x.id === s);
    const defaults: Record<string, string> = {
      custom: "",
      feature:
        "Add input validation to POST /tasks: reject titles that are empty or longer than 80 characters, returning a 400 with a helpful message. Keep existing behaviour intact.",
      bug: "Users report that searching 'ps5' returns no results even though the products exist in the catalogue. Investigate and fix.",
      recovery:
        "npm test on main is red. Get the suite green again without weakening what the tests check.",
      security:
        "We open-source this repository on Friday. Do a security pass and fix anything critical before then.",
      ambiguity: "Make the search feature better.",
    };
    if (found) setRequest(defaults[s]);
  };

  // ── Derived state from the event stream ────────────────────────────────────
  const events: EventDTO[] = mission?.events || [];
  const lastEvent = events[events.length - 1];
  const latestTasks = [...events].reverse().find((e) => e.type === "tasks")?.detail?.tasks || [];
  const latestState = [...events].reverse().find((e) => e.type === "state")?.detail?.snapshot || [];
  const awaiting = mission?.status === "awaiting_approval";
  const gateEvent = [...events].reverse().find((e) => e.type === "approval_request");
  const completeEvent = events.find((e) => e.type === "complete");
  const latestTest = [...events].reverse().find((e) => e.type === "test");
  const diffs = events.filter((e) => e.type === "file_edit");
  const latestVerify = [...events].reverse().find((e) => e.type === "verify");
  const latestSecurity = [...events]
    .reverse()
    .find((e) => e.type === "security" && e.detail?.findings?.length > 0);
  const agentsPresent = Array.from(new Set(events.map((e) => e.agent)));
  const filtered = agentFilter === "all" ? events : events.filter((e) => e.agent === agentFilter);
  const running = mission?.status === "running";
  const preparing = mission?.status === "preparing";
  const busyMission = running || preparing;

  const statusChip = () => {
    const map: Record<string, { label: string; cls: string }> = {
      running: { label: running ? "mission in progress…" : "running", cls: "border-amber-400/40 bg-amber-400/10 text-amber-300" },
      preparing: { label: "the guild is convening…", cls: "border-violet-400/40 bg-violet-400/10 text-violet-300" },
      awaiting_approval: { label: "awaiting your approval", cls: "border-orange-400/50 bg-orange-400/15 text-orange-300" },
      completed: { label: "mission complete", cls: "border-emerald-400/40 bg-emerald-400/10 text-emerald-300" },
      escalated: { label: "escalated to human", cls: "border-rose-400/40 bg-rose-400/10 text-rose-300" },
    };
    if (!mission) return null;
    const s = map[mission.status] || { label: mission.status, cls: "border-border text-zinc-300" };
    return (
      <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-semibold ${s.cls}`}>
        {(running || preparing) && <Loader2 className="h-3 w-3 animate-spin" />}
        {s.label}
      </span>
    );
  };

  return (
    <div className="flex min-h-screen flex-col">
      {/* ── Header ── */}
      <header className="sticky top-0 z-20 border-b border-border/70 bg-[oklch(0.17_0.014_305/0.85)] backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
          <span className="rounded-lg border border-primary/40 bg-primary/10 p-2">
            <ToriiMark className="h-5 w-5 text-primary" />
          </span>
          <div className="min-w-0">
            <h1 className="text-base font-black tracking-tight sm:text-lg">
              Dev<span className="dp-gold-text">Pilot</span>
              <span className="ml-2 hidden text-xs font-medium text-zinc-500 sm:inline">
                自律開発ギルド — The Mystic Mikado&apos;s AI Engineering Guild
              </span>
            </h1>
            <p className="text-[10px] leading-tight text-zinc-500">
              Plan like a Shogun · Build like a Samurai · Test like a Sentinel · Adapt until the mission is complete
            </p>
          </div>
          <div className="ml-auto">{statusChip()}</div>
        </div>
        {/* Tabs */}
        <div className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4">
          {TABS.map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-1.5 whitespace-nowrap border-b-2 px-3 py-2 text-xs font-semibold transition-colors ${
                  tab === t.id
                    ? "border-primary text-zinc-100"
                    : "border-transparent text-zinc-500 hover:text-zinc-300"
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                {t.label}
                {t.id === "log" && events.length > 0 && (
                  <span className="rounded bg-black/40 px-1 font-mono text-[9px] text-zinc-400">{events.length}</span>
                )}
              </button>
            );
          })}
        </div>
      </header>

      {/* ── Body ── */}
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-5">
        {tab === "control" && (
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-[340px_minmax(0,1fr)]">
            {/* Left: mission setup */}
            <div className="space-y-4">
              <div className="rounded-xl border border-border bg-card/40 p-4">
                <h2 className="mb-3 text-xs font-bold uppercase tracking-widest text-amber-300/90">
                  1 · Choose a mission
                </h2>
                <ScenarioPicker value={scenario} onChange={onScenarioChange} disabled={busyMission} />
                {scenario === "custom" && (
                  <p className="mt-2 rounded-lg border border-violet-400/30 bg-violet-400/5 px-3 py-2 text-[11px] leading-relaxed text-violet-200">
                    Live AI mode: the Shogun, Samurai and Shadow Council convene for real on your problem — planning, coding and reviewing with actual LLM calls. This takes up to a couple of minutes.
                  </p>
                )}
                <h2 className="mb-2 mt-4 text-xs font-bold uppercase tracking-widest text-amber-300/90">
                  2 · The decree {scenario === "custom" ? "— your problem statement" : "(natural language)"}
                </h2>
                <textarea
                  value={request}
                  onChange={(e) => setRequest(e.target.value)}
                  rows={4}
                  disabled={busyMission}
                  placeholder={
                    scenario === "custom"
                      ? "Describe your problem in plain words — e.g. 'Write a program that checks if a password is strong' or 'Build a tip calculator for 3 people'…"
                      : "Natural-language request for the guild…"
                  }
                  className="w-full rounded-lg border border-border bg-black/30 p-3 text-xs leading-relaxed text-zinc-100 placeholder:text-zinc-600 focus:border-primary/50 focus:outline-none disabled:opacity-60"
                />
                {launchError && (
                  <p className="mt-2 rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-[11px] text-rose-300">{launchError}</p>
                )}
                <button
                  onClick={launch}
                  disabled={launching || busyMission}
                  className={`relative mt-3 inline-flex w-full items-center justify-center gap-2 overflow-hidden rounded-lg bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground transition-all hover:brightness-110 active:scale-[0.98] disabled:opacity-40 ${
                    !launching && !busyMission ? "dp-anim-glow dp-shine" : ""
                  }`}
                >
                  {launching || preparing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Rocket className="h-4 w-4" />}
                  {preparing
                    ? "Guild convening…"
                    : running
                      ? "Mission in progress…"
                      : scenario === "custom"
                        ? "Send the decree to the guild"
                        : mission
                          ? "Launch new mission"
                          : "Launch the guild"}
                </button>
              </div>

              <div className="rounded-xl border border-border bg-card/40 p-4">
                <h2 className="mb-2 text-xs font-bold uppercase tracking-widest text-amber-300/90">
                  Mission history
                </h2>
                <History missions={history} currentId={mission?.id || null} onSelect={selectMission} />
              </div>
            </div>

            {/* Right: live war room */}
            <div className="space-y-4">
              <AgentRow
                activeAgent={(awaiting ? "human" : lastEvent?.agent) as any}
                awaiting={awaiting}
              />

              {awaiting && gateEvent && (
                <ApprovalGate detail={gateEvent.detail} busy={deciding} onDecision={decide} />
              )}

              {completeEvent && (
                <div className="dp-anim-gate dp-anim-glow-green rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-4">
                  <p className="text-xs font-bold uppercase tracking-widest text-emerald-300">
                    Mission outcome — evidence-based completion
                  </p>
                  <p className="mt-1 text-xs leading-relaxed text-emerald-100">
                    {completeEvent.detail?.outcome}
                  </p>
                </div>
              )}

              {!mission && (
                <div className="dp-anim-up rounded-xl border border-dashed border-border p-8 text-center">
                  <Moon className="mx-auto mb-2 h-6 w-6 text-zinc-600" />
                  <p className="text-sm font-semibold text-zinc-300">No mission running</p>
                  <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-zinc-500">
                    Pick a scenario on the left and launch the guild. You will watch five agents plan,
                    build, test, review — and they will stop and ask YOU before applying any change.
                    Start with <b className="text-zinc-300">Test-Driven Recovery</b> to see the feedback loop,
                    or bring your own problem with <b className="text-zinc-300">Custom Mission</b>.
                  </p>
                </div>
              )}

              {preparing && (
                <div className="dp-anim-gate rounded-xl border border-violet-400/40 bg-violet-400/10 p-5 text-center">
                  <Loader2 className="mx-auto mb-2 h-6 w-6 animate-spin text-violet-300" />
                  <p className="text-sm font-bold uppercase tracking-widest text-violet-200">
                    The guild is convening on your decree…
                  </p>
                  <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-zinc-400">
                    The Shogun is analysing your problem statement, the Samurai is about to forge the
                    code, and the Shadow Council is sharpening its review lens. This uses live AI calls —
                    typically 30–90 seconds. Do not close the tab.
                  </p>
                </div>
              )}

              {mission?.status === "escalated" && mission.outcome && !completeEvent && (
                <div className="dp-anim-gate rounded-xl border border-rose-500/40 bg-rose-500/10 p-4">
                  <p className="text-xs font-bold uppercase tracking-widest text-rose-300">Mission closed — escalated</p>
                  <p className="mt-1 text-xs leading-relaxed text-rose-100">{mission.outcome}</p>
                </div>
              )}

              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-xl border border-border bg-card/40 p-4">
                  <h2 className="mb-2 text-xs font-bold uppercase tracking-widest text-amber-300/90">
                    Task board
                  </h2>
                  <TaskBoard tasks={latestTasks} />
                </div>
                <div className="rounded-xl border border-border bg-card/40 p-4">
                  <h2 className="mb-2 text-xs font-bold uppercase tracking-widest text-amber-300/90">
                    Shared mission state
                  </h2>
                  <SharedState snapshot={latestState} />
                </div>
              </div>

              {events.length > 0 && (
                <div className="rounded-xl border border-border bg-card/40 p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <h2 className="text-xs font-bold uppercase tracking-widest text-amber-300/90">
                      Live activity
                    </h2>
                    <button onClick={() => setTab("log")} className="text-[11px] text-zinc-400 underline-offset-2 hover:text-zinc-200 hover:underline">
                      open full run log →
                    </button>
                  </div>
                  <div className="space-y-0.5">
                    {events.slice(-4).map((ev) => (
                      <div key={ev.id} className="flex items-center gap-2 border-l-2 border-border/60 py-1 pl-3 text-xs">
                        <span className="min-w-0 flex-1 truncate text-zinc-300">{ev.title}</span>
                        <span className="shrink-0 font-mono text-[9px] text-zinc-600">{ev.agent}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {repo && <RepoViewer repo={repo} />}
            </div>
          </div>
        )}

        {tab === "log" && (
          <div className="space-y-3">
            {events.length === 0 ? (
              <p className="py-16 text-center text-sm text-zinc-500">No log entries yet — launch a mission first.</p>
            ) : (
              <>
                <div className="flex flex-wrap gap-1.5">
                  {["all", ...agentsPresent].map((a) => (
                    <button
                      key={a}
                      onClick={() => setAgentFilter(a)}
                      className={`rounded-full border px-3 py-1 text-[11px] font-semibold transition-colors ${
                        agentFilter === a
                          ? "border-primary/60 bg-primary/15 text-zinc-100"
                          : "border-border bg-card/40 text-zinc-400 hover:text-zinc-200"
                      }`}
                    >
                      {a === "all" ? "All agents" : a}
                    </button>
                  ))}
                </div>
                <div className="rounded-xl border border-border bg-card/30 p-4">
                  {filtered.map((ev) => (
                    <EventCard key={ev.id} ev={ev} />
                  ))}
                  <div ref={logEndRef} />
                </div>
              </>
            )}
          </div>
        )}

        {tab === "evidence" && (
          <div className="space-y-4">
            {completeEvent && (
              <div className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-4">
                <p className="text-xs font-bold uppercase tracking-widest text-emerald-300">Final outcome</p>
                <p className="mt-1 text-xs leading-relaxed text-emerald-100">{completeEvent.detail?.outcome}</p>
              </div>
            )}
            {!events.length && (
              <p className="py-16 text-center text-sm text-zinc-500">No evidence yet — launch a mission first.</p>
            )}
            {latestTest && (
              <div className="rounded-xl border border-border bg-card/40 p-4">
                <h2 className="mb-2 text-xs font-bold uppercase tracking-widest text-amber-300/90">
                  Latest test run (Sentinel)
                </h2>
                <EventCard ev={latestTest} defaultOpen />
              </div>
            )}
            {latestVerify && (
              <div className="rounded-xl border border-border bg-card/40 p-4">
                <h2 className="mb-2 text-xs font-bold uppercase tracking-widest text-amber-300/90">
                  Independent verification (Apostle)
                </h2>
                <EventCard ev={latestVerify} defaultOpen />
              </div>
            )}
            {latestSecurity && (
              <div className="rounded-xl border border-border bg-card/40 p-4">
                <h2 className="mb-2 text-xs font-bold uppercase tracking-widest text-amber-300/90">
                  Security findings (Shadow Council)
                </h2>
                <EventCard ev={latestSecurity} defaultOpen />
              </div>
            )}
            {diffs.length > 0 && (
              <div className="rounded-xl border border-border bg-card/40 p-4">
                <h2 className="mb-2 text-xs font-bold uppercase tracking-widest text-amber-300/90">
                  Proposed changes ({diffs.length})
                </h2>
                <div className="space-y-3">
                  {diffs.map((d) => (
                    <EventCard key={d.id} ev={d} defaultOpen />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {tab === "architecture" && <Architecture />}
      </main>

      {/* ── Footer (sticky) ── */}
      <footer className="mt-auto border-t border-border/70 bg-black/20">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-3 text-[10px] text-zinc-500">
          <p>
            DevPilot — PECathon 2026 · PS-001. A multi-agent AI engineering guild: coordination,
            feedback loops and human oversight over a sandboxed local repo.
          </p>
          <p className="font-mono">shogun · samurai · sentinel · apostle · shadow</p>
        </div>
      </footer>
    </div>
  );
}
